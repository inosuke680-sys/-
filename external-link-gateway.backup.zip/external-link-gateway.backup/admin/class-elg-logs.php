<?php
/**
 * ログページクラス
 *
 * プラグインのログ画面を提供します。
 *
 * @package ExternalLinkGateway
 * @since 1.0.0
 */

// 直接アクセスを防止
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * ELG_Logs クラス
 */
class ELG_Logs {

    /**
     * ログページをレンダリング
     */
    public function render() {
        $logger = new ELG_Logger();
        $level = isset( $_GET['level'] ) ? sanitize_text_field( wp_unslash( $_GET['level'] ) ) : null;
        $logs = $logger->get_logs( array( 'level' => $level, 'limit' => 100 ) );

        require_once ELG_PLUGIN_DIR . 'admin/views/logs.php';
    }
}
