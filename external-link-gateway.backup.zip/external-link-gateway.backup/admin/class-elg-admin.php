<?php
/**
 * 管理画面クラス
 *
 * 管理画面のメニューやページを管理します。
 *
 * @package ExternalLinkGateway
 * @since 1.0.0
 */

// 直接アクセスを防止
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * ELG_Admin クラス
 */
class ELG_Admin {

    /**
     * コンストラクタ
     */
    public function __construct() {
        add_action( 'admin_menu', array( $this, 'add_admin_menu' ) );
        add_action( 'admin_enqueue_scripts', array( $this, 'enqueue_scripts' ) );
    }

    /**
     * 管理メニューを追加
     */
    public function add_admin_menu() {
        // メインメニュー
        add_menu_page(
            __( 'Link Gateway', 'external-link-gateway' ),
            __( 'Link Gateway', 'external-link-gateway' ),
            'view_elg_statistics',
            'elg-dashboard',
            array( $this, 'display_dashboard' ),
            'dashicons-external',
            30
        );

        // ダッシュボード（統計）
        add_submenu_page(
            'elg-dashboard',
            __( 'Dashboard', 'external-link-gateway' ),
            __( 'Dashboard', 'external-link-gateway' ),
            'view_elg_statistics',
            'elg-statistics',
            array( $this, 'display_statistics' )
        );

        // 設定ページ
        add_submenu_page(
            'elg-dashboard',
            __( 'Settings', 'external-link-gateway' ),
            __( 'Settings', 'external-link-gateway' ),
            'manage_elg_settings',
            'elg-settings',
            array( $this, 'display_settings' )
        );

        // ログページ
        add_submenu_page(
            'elg-dashboard',
            __( 'Logs', 'external-link-gateway' ),
            __( 'Logs', 'external-link-gateway' ),
            'manage_elg_settings',
            'elg-logs',
            array( $this, 'display_logs' )
        );

        // 最初のサブメニュー（Dashboard）を削除
        remove_submenu_page( 'elg-dashboard', 'elg-dashboard' );
    }

    /**
     * 管理画面用スクリプトとスタイルを読み込み
     *
     * @param string $hook フック名
     */
    public function enqueue_scripts( $hook ) {
        // プラグインページのみで読み込み
        if ( strpos( $hook, 'elg-' ) === false ) {
            return;
        }

        // CSS
        wp_enqueue_style(
            'elg-admin',
            ELG_PLUGIN_URL . 'assets/css/admin.css',
            array(),
            ELG_VERSION
        );

        // JavaScript
        wp_enqueue_script(
            'elg-admin',
            ELG_PLUGIN_URL . 'assets/js/admin.js',
            array( 'jquery', 'wp-api' ),
            ELG_VERSION,
            true
        );

        // Chart.js
        wp_enqueue_script(
            'chart-js',
            'https://cdn.jsdelivr.net/npm/chart.js@3.9.1/dist/chart.min.js',
            array(),
            '3.9.1',
            true
        );

        // JavaScriptに変数を渡す
        wp_localize_script(
            'elg-admin',
            'elgAdminData',
            array(
                'ajaxUrl' => admin_url( 'admin-ajax.php' ),
                'apiUrl' => rest_url( 'elg/v1/' ),
                'nonce' => wp_create_nonce( 'wp_rest' ),
            )
        );
    }

    /**
     * ダッシュボードページを表示
     */
    public function display_dashboard() {
        wp_redirect( admin_url( 'admin.php?page=elg-statistics' ) );
        exit;
    }

    /**
     * 統計ページを表示
     */
    public function display_statistics() {
        require_once ELG_PLUGIN_DIR . 'admin/class-elg-statistics.php';
        $statistics_page = new ELG_Statistics();
        $statistics_page->render();
    }

    /**
     * 設定ページを表示
     */
    public function display_settings() {
        require_once ELG_PLUGIN_DIR . 'admin/class-elg-settings.php';
        $settings_page = new ELG_Settings();
        $settings_page->render();
    }

    /**
     * ログページを表示
     */
    public function display_logs() {
        require_once ELG_PLUGIN_DIR . 'admin/class-elg-logs.php';
        $logs_page = new ELG_Logs();
        $logs_page->render();
    }
}
