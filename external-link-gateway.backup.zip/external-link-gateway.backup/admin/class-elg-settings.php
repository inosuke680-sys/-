<?php
/**
 * 設定ページクラス
 *
 * プラグインの設定画面を提供します。
 *
 * @package ExternalLinkGateway
 * @since 1.0.0
 */

// 直接アクセスを防止
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * ELG_Settings クラス
 */
class ELG_Settings {

    /**
     * コンストラクタ
     */
    public function __construct() {
        add_action( 'admin_init', array( $this, 'register_settings' ) );
        add_action( 'admin_post_elg_save_settings', array( $this, 'save_settings' ) );
    }

    /**
     * 設定を登録
     */
    public function register_settings() {
        register_setting( 'elg_general_settings', 'elg_general_settings' );
        register_setting( 'elg_exclusion_settings', 'elg_exclusion_settings' );
        register_setting( 'elg_appearance_settings', 'elg_appearance_settings' );
        register_setting( 'elg_security_settings', 'elg_security_settings' );
        register_setting( 'elg_analytics_settings', 'elg_analytics_settings' );
        register_setting( 'elg_advanced_settings', 'elg_advanced_settings' );
    }

    /**
     * 設定を保存
     */
    public function save_settings() {
        if ( ! current_user_can( 'manage_elg_settings' ) ) {
            wp_die( esc_html__( 'You do not have permission to access this page.', 'external-link-gateway' ) );
        }

        check_admin_referer( 'elg_save_settings' );

        // 各設定グループを保存
        $settings_groups = array(
            'elg_general_settings',
            'elg_exclusion_settings',
            'elg_appearance_settings',
            'elg_security_settings',
            'elg_analytics_settings',
            'elg_advanced_settings',
        );

        foreach ( $settings_groups as $group ) {
            if ( isset( $_POST[ $group ] ) ) {
                update_option( $group, wp_unslash( $_POST[ $group ] ) );
            }
        }

        // リライトルールをフラッシュ
        flush_rewrite_rules();

        wp_redirect( admin_url( 'admin.php?page=elg-settings&updated=true' ) );
        exit;
    }

    /**
     * 設定ページをレンダリング
     */
    public function render() {
        require_once ELG_PLUGIN_DIR . 'admin/views/settings.php';
    }
}
