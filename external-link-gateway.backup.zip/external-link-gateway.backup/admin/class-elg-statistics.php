<?php
/**
 * 統計ページクラス
 *
 * プラグインの統計・分析画面を提供します。
 *
 * @package ExternalLinkGateway
 * @since 1.0.0
 */

// 直接アクセスを防止
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * ELG_Statistics クラス
 */
class ELG_Statistics {

    /**
     * 統計ページをレンダリング
     */
    public function render() {
        $analytics = new ELG_Analytics();
        $period = isset( $_GET['period'] ) ? sanitize_text_field( wp_unslash( $_GET['period'] ) ) : 'last_30_days';
        $stats = $analytics->get_statistics( array( 'period' => $period ) );

        require_once ELG_PLUGIN_DIR . 'admin/views/statistics.php';
    }
}
