<?php if ( ! defined( 'ABSPATH' ) ) exit; ?>

<table class="form-table">
    <tr>
        <th scope="row"><?php esc_html_e( 'Page Title', 'external-link-gateway' ); ?></th>
        <td>
            <input type="text" name="elg_appearance_settings[page_title]" value="<?php echo esc_attr( isset( $appearance_settings['page_title'] ) ? $appearance_settings['page_title'] : __( 'Redirecting...', 'external-link-gateway' ) ); ?>" class="regular-text">
        </td>
    </tr>
    <tr>
        <th scope="row"><?php esc_html_e( 'Page Heading', 'external-link-gateway' ); ?></th>
        <td>
            <input type="text" name="elg_appearance_settings[page_heading]" value="<?php echo esc_attr( isset( $appearance_settings['page_heading'] ) ? $appearance_settings['page_heading'] : __( 'You are being redirected', 'external-link-gateway' ) ); ?>" class="regular-text">
        </td>
    </tr>
    <tr>
        <th scope="row"><?php esc_html_e( 'Page Message', 'external-link-gateway' ); ?></th>
        <td>
            <textarea name="elg_appearance_settings[page_message]" rows="3" class="large-text"><?php echo esc_textarea( isset( $appearance_settings['page_message'] ) ? $appearance_settings['page_message'] : __( 'Please wait while we redirect you to the external site...', 'external-link-gateway' ) ); ?></textarea>
        </td>
    </tr>
    <tr>
        <th scope="row"><?php esc_html_e( 'Display Options', 'external-link-gateway' ); ?></th>
        <td>
            <label>
                <input type="checkbox" name="elg_appearance_settings[show_countdown]" value="1" <?php checked( ! empty( $appearance_settings['show_countdown'] ) ); ?>>
                <?php esc_html_e( 'Show countdown timer', 'external-link-gateway' ); ?>
            </label><br>
            <label>
                <input type="checkbox" name="elg_appearance_settings[show_url]" value="1" <?php checked( ! empty( $appearance_settings['show_url'] ) ); ?>>
                <?php esc_html_e( 'Show destination URL', 'external-link-gateway' ); ?>
            </label><br>
            <label>
                <input type="checkbox" name="elg_appearance_settings[show_warning]" value="1" <?php checked( ! empty( $appearance_settings['show_warning'] ) ); ?>>
                <?php esc_html_e( 'Show warning message', 'external-link-gateway' ); ?>
            </label>
        </td>
    </tr>
    <tr>
        <th scope="row"><?php esc_html_e( 'Custom CSS', 'external-link-gateway' ); ?></th>
        <td>
            <textarea name="elg_appearance_settings[custom_css]" rows="10" class="large-text code"><?php echo esc_textarea( isset( $appearance_settings['custom_css'] ) ? $appearance_settings['custom_css'] : '' ); ?></textarea>
        </td>
    </tr>
</table>
