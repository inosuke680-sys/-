<?php if ( ! defined( 'ABSPATH' ) ) exit; ?>

<table class="form-table">
    <tr>
        <th scope="row"><?php esc_html_e( 'Enable Tracking', 'external-link-gateway' ); ?></th>
        <td>
            <label>
                <input type="checkbox" name="elg_analytics_settings[enable_tracking]" value="1" <?php checked( ! empty( $analytics_settings['enable_tracking'] ) ); ?>>
                <?php esc_html_e( 'Track click statistics', 'external-link-gateway' ); ?>
            </label>
        </td>
    </tr>
    <tr>
        <th scope="row"><?php esc_html_e( 'Tracking Options', 'external-link-gateway' ); ?></th>
        <td>
            <label>
                <input type="checkbox" name="elg_analytics_settings[track_anonymous]" value="1" <?php checked( ! empty( $analytics_settings['track_anonymous'] ) ); ?>>
                <?php esc_html_e( 'Track anonymous users', 'external-link-gateway' ); ?>
            </label><br>
            <label>
                <input type="checkbox" name="elg_analytics_settings[track_logged_in]" value="1" <?php checked( ! empty( $analytics_settings['track_logged_in'] ) ); ?>>
                <?php esc_html_e( 'Track logged-in users', 'external-link-gateway' ); ?>
            </label><br>
            <label>
                <input type="checkbox" name="elg_analytics_settings[enable_device_detection]" value="1" <?php checked( ! empty( $analytics_settings['enable_device_detection'] ) ); ?>>
                <?php esc_html_e( 'Detect device type and browser', 'external-link-gateway' ); ?>
            </label><br>
            <label>
                <input type="checkbox" name="elg_analytics_settings[anonymize_ip]" value="1" <?php checked( ! empty( $analytics_settings['anonymize_ip'] ) ); ?>>
                <?php esc_html_e( 'Anonymize IP addresses (GDPR compliance)', 'external-link-gateway' ); ?>
            </label>
        </td>
    </tr>
    <tr>
        <th scope="row"><?php esc_html_e( 'Data Retention', 'external-link-gateway' ); ?></th>
        <td>
            <input type="number" name="elg_analytics_settings[retention_days]" value="<?php echo esc_attr( isset( $analytics_settings['retention_days'] ) ? $analytics_settings['retention_days'] : 90 ); ?>" min="1" max="365" class="small-text">
            <?php esc_html_e( 'days', 'external-link-gateway' ); ?>
            <p class="description"><?php esc_html_e( 'How long to keep analytics data', 'external-link-gateway' ); ?></p>
        </td>
    </tr>
</table>
