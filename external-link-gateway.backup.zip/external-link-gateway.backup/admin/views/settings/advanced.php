<?php if ( ! defined( 'ABSPATH' ) ) exit; ?>

<table class="form-table">
    <tr>
        <th scope="row"><?php esc_html_e( 'Cache', 'external-link-gateway' ); ?></th>
        <td>
            <label>
                <input type="checkbox" name="elg_advanced_settings[enable_cache]" value="1" <?php checked( ! empty( $advanced_settings['enable_cache'] ) ); ?>>
                <?php esc_html_e( 'Enable caching for better performance', 'external-link-gateway' ); ?>
            </label>
        </td>
    </tr>
    <tr>
        <th scope="row"><?php esc_html_e( 'Debug Mode', 'external-link-gateway' ); ?></th>
        <td>
            <label>
                <input type="checkbox" name="elg_advanced_settings[enable_debug]" value="1" <?php checked( ! empty( $advanced_settings['enable_debug'] ) ); ?>>
                <?php esc_html_e( 'Enable debug mode (logs all events)', 'external-link-gateway' ); ?>
            </label>
        </td>
    </tr>
    <tr>
        <th scope="row"><?php esc_html_e( 'Log Level', 'external-link-gateway' ); ?></th>
        <td>
            <select name="elg_advanced_settings[log_level]">
                <option value="error" <?php selected( isset( $advanced_settings['log_level'] ) ? $advanced_settings['log_level'] : 'error', 'error' ); ?>><?php esc_html_e( 'Error', 'external-link-gateway' ); ?></option>
                <option value="warning" <?php selected( isset( $advanced_settings['log_level'] ) ? $advanced_settings['log_level'] : 'error', 'warning' ); ?>><?php esc_html_e( 'Warning', 'external-link-gateway' ); ?></option>
                <option value="info" <?php selected( isset( $advanced_settings['log_level'] ) ? $advanced_settings['log_level'] : 'error', 'info' ); ?>><?php esc_html_e( 'Info', 'external-link-gateway' ); ?></option>
                <option value="debug" <?php selected( isset( $advanced_settings['log_level'] ) ? $advanced_settings['log_level'] : 'error', 'debug' ); ?>><?php esc_html_e( 'Debug', 'external-link-gateway' ); ?></option>
            </select>
        </td>
    </tr>
    <tr>
        <th scope="row"><?php esc_html_e( 'Cleanup', 'external-link-gateway' ); ?></th>
        <td>
            <label>
                <input type="checkbox" name="elg_advanced_settings[cleanup_enabled]" value="1" <?php checked( ! empty( $advanced_settings['cleanup_enabled'] ) ); ?>>
                <?php esc_html_e( 'Automatically cleanup old data', 'external-link-gateway' ); ?>
            </label>
        </td>
    </tr>
</table>
