<?php if ( ! defined( 'ABSPATH' ) ) exit; ?>

<table class="form-table">
    <tr>
        <th scope="row"><?php esc_html_e( 'Exclude Domains', 'external-link-gateway' ); ?></th>
        <td>
            <textarea name="elg_exclusion_settings[exclude_domains]" rows="5" class="large-text"><?php echo esc_textarea( isset( $exclusion_settings['exclude_domains'] ) ? implode( "\n", (array) $exclusion_settings['exclude_domains'] ) : '' ); ?></textarea>
            <p class="description"><?php esc_html_e( 'One domain per line (e.g., example.com)', 'external-link-gateway' ); ?></p>
        </td>
    </tr>
    <tr>
        <th scope="row"><?php esc_html_e( 'Whitelist Domains', 'external-link-gateway' ); ?></th>
        <td>
            <textarea name="elg_exclusion_settings[whitelist_domains]" rows="5" class="large-text"><?php echo esc_textarea( isset( $exclusion_settings['whitelist_domains'] ) ? implode( "\n", (array) $exclusion_settings['whitelist_domains'] ) : '' ); ?></textarea>
            <p class="description"><?php esc_html_e( 'Domains that should always be converted (overrides exclusions)', 'external-link-gateway' ); ?></p>
        </td>
    </tr>
</table>
