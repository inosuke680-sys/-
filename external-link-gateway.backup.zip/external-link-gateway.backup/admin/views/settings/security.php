<?php if ( ! defined( 'ABSPATH' ) ) exit; ?>

<table class="form-table">
    <tr>
        <th scope="row"><?php esc_html_e( 'URL Validation', 'external-link-gateway' ); ?></th>
        <td>
            <label>
                <input type="checkbox" name="elg_security_settings[validate_urls]" value="1" <?php checked( ! empty( $security_settings['validate_urls'] ) ); ?>>
                <?php esc_html_e( 'Validate URLs before redirecting', 'external-link-gateway' ); ?>
            </label><br>
            <label>
                <input type="checkbox" name="elg_security_settings[block_suspicious_urls]" value="1" <?php checked( ! empty( $security_settings['block_suspicious_urls'] ) ); ?>>
                <?php esc_html_e( 'Block suspicious URLs', 'external-link-gateway' ); ?>
            </label>
        </td>
    </tr>
    <tr>
        <th scope="row"><?php esc_html_e( 'Rate Limiting', 'external-link-gateway' ); ?></th>
        <td>
            <label>
                <input type="checkbox" name="elg_security_settings[rate_limiting]" value="1" <?php checked( ! empty( $security_settings['rate_limiting'] ) ); ?>>
                <?php esc_html_e( 'Enable rate limiting', 'external-link-gateway' ); ?>
            </label><br>
            <input type="number" name="elg_security_settings[rate_limit_count]" value="<?php echo esc_attr( isset( $security_settings['rate_limit_count'] ) ? $security_settings['rate_limit_count'] : 100 ); ?>" class="small-text">
            <?php esc_html_e( 'requests per', 'external-link-gateway' ); ?>
            <input type="number" name="elg_security_settings[rate_limit_period]" value="<?php echo esc_attr( isset( $security_settings['rate_limit_period'] ) ? $security_settings['rate_limit_period'] : 3600 ); ?>" class="small-text">
            <?php esc_html_e( 'seconds', 'external-link-gateway' ); ?>
        </td>
    </tr>
</table>
