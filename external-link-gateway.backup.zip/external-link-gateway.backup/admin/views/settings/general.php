<?php
/**
 * 一般設定タブ
 *
 * @package ExternalLinkGateway
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}
?>

<table class="form-table">
    <tr>
        <th scope="row"><?php esc_html_e( 'Enable Plugin', 'external-link-gateway' ); ?></th>
        <td>
            <label>
                <input type="checkbox" name="elg_general_settings[enable_plugin]" value="1" <?php checked( ! empty( $general_settings['enable_plugin'] ) ); ?>>
                <?php esc_html_e( 'Enable external link conversion', 'external-link-gateway' ); ?>
            </label>
        </td>
    </tr>
    <tr>
        <th scope="row"><?php esc_html_e( 'Redirect Slug', 'external-link-gateway' ); ?></th>
        <td>
            <input type="text" name="elg_general_settings[redirect_slug]" value="<?php echo esc_attr( isset( $general_settings['redirect_slug'] ) ? $general_settings['redirect_slug'] : 'goto' ); ?>" class="regular-text">
            <p class="description"><?php esc_html_e( 'URL slug for redirect pages (e.g., yoursite.com/goto/abc123)', 'external-link-gateway' ); ?></p>
        </td>
    </tr>
    <tr>
        <th scope="row"><?php esc_html_e( 'Redirect Delay (seconds)', 'external-link-gateway' ); ?></th>
        <td>
            <input type="number" name="elg_general_settings[redirect_delay]" value="<?php echo esc_attr( isset( $general_settings['redirect_delay'] ) ? $general_settings['redirect_delay'] : 3 ); ?>" min="0" max="60" class="small-text">
            <p class="description"><?php esc_html_e( 'Time to wait before redirecting (0 for instant redirect)', 'external-link-gateway' ); ?></p>
        </td>
    </tr>
    <tr>
        <th scope="row"><?php esc_html_e( 'Auto Convert Links', 'external-link-gateway' ); ?></th>
        <td>
            <label>
                <input type="checkbox" name="elg_general_settings[auto_convert_links]" value="1" <?php checked( ! empty( $general_settings['auto_convert_links'] ) ); ?>>
                <?php esc_html_e( 'Automatically convert external links in content', 'external-link-gateway' ); ?>
            </label>
        </td>
    </tr>
    <tr>
        <th scope="row"><?php esc_html_e( 'Open in New Tab', 'external-link-gateway' ); ?></th>
        <td>
            <label>
                <input type="checkbox" name="elg_general_settings[open_in_new_tab]" value="1" <?php checked( ! empty( $general_settings['open_in_new_tab'] ) ); ?>>
                <?php esc_html_e( 'Open external links in a new tab', 'external-link-gateway' ); ?>
            </label>
        </td>
    </tr>
    <tr>
        <th scope="row"><?php esc_html_e( 'SEO Settings', 'external-link-gateway' ); ?></th>
        <td>
            <label>
                <input type="checkbox" name="elg_general_settings[add_nofollow]" value="1" <?php checked( ! empty( $general_settings['add_nofollow'] ) ); ?>>
                <?php esc_html_e( 'Add rel="nofollow" to external links', 'external-link-gateway' ); ?>
            </label><br>
            <label>
                <input type="checkbox" name="elg_general_settings[add_sponsored]" value="1" <?php checked( ! empty( $general_settings['add_sponsored'] ) ); ?>>
                <?php esc_html_e( 'Add rel="sponsored" to external links', 'external-link-gateway' ); ?>
            </label><br>
            <label>
                <input type="checkbox" name="elg_general_settings[add_ugc]" value="1" <?php checked( ! empty( $general_settings['add_ugc'] ) ); ?>>
                <?php esc_html_e( 'Add rel="ugc" to external links', 'external-link-gateway' ); ?>
            </label>
        </td>
    </tr>
</table>
