<?php
/**
 * ログページのビュー
 *
 * @package ExternalLinkGateway
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}
?>

<div class="wrap elg-logs-wrap">
    <h1><?php echo esc_html( get_admin_page_title() ); ?></h1>

    <div class="elg-logs-filters">
        <select id="elg-level-filter" onchange="window.location.href='?page=elg-logs&level='+this.value">
            <option value=""><?php esc_html_e( 'All Levels', 'external-link-gateway' ); ?></option>
            <option value="debug" <?php selected( $level, 'debug' ); ?>><?php esc_html_e( 'Debug', 'external-link-gateway' ); ?></option>
            <option value="info" <?php selected( $level, 'info' ); ?>><?php esc_html_e( 'Info', 'external-link-gateway' ); ?></option>
            <option value="warning" <?php selected( $level, 'warning' ); ?>><?php esc_html_e( 'Warning', 'external-link-gateway' ); ?></option>
            <option value="error" <?php selected( $level, 'error' ); ?>><?php esc_html_e( 'Error', 'external-link-gateway' ); ?></option>
            <option value="critical" <?php selected( $level, 'critical' ); ?>><?php esc_html_e( 'Critical', 'external-link-gateway' ); ?></option>
        </select>
    </div>

    <table class="wp-list-table widefat fixed striped">
        <thead>
            <tr>
                <th style="width: 80px;"><?php esc_html_e( 'Level', 'external-link-gateway' ); ?></th>
                <th><?php esc_html_e( 'Message', 'external-link-gateway' ); ?></th>
                <th style="width: 120px;"><?php esc_html_e( 'IP Address', 'external-link-gateway' ); ?></th>
                <th style="width: 180px;"><?php esc_html_e( 'Time', 'external-link-gateway' ); ?></th>
            </tr>
        </thead>
        <tbody>
            <?php if ( ! empty( $logs ) ) : ?>
                <?php foreach ( $logs as $log ) : ?>
                    <tr>
                        <td>
                            <span class="elg-log-level elg-log-level-<?php echo esc_attr( $log->log_level ); ?>">
                                <?php echo esc_html( strtoupper( $log->log_level ) ); ?>
                            </span>
                        </td>
                        <td>
                            <?php echo esc_html( $log->message ); ?>
                            <?php if ( ! empty( $log->context ) ) : ?>
                                <details>
                                    <summary><?php esc_html_e( 'Details', 'external-link-gateway' ); ?></summary>
                                    <pre><?php echo esc_html( is_array( $log->context ) ? wp_json_encode( $log->context, JSON_PRETTY_PRINT ) : $log->context ); ?></pre>
                                </details>
                            <?php endif; ?>
                        </td>
                        <td><?php echo esc_html( $log->ip_address ); ?></td>
                        <td><?php echo esc_html( $log->created_at ); ?></td>
                    </tr>
                <?php endforeach; ?>
            <?php else : ?>
                <tr>
                    <td colspan="4"><?php esc_html_e( 'No logs found', 'external-link-gateway' ); ?></td>
                </tr>
            <?php endif; ?>
        </tbody>
    </table>
</div>
