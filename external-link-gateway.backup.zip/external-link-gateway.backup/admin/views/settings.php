<?php
/**
 * 設定ページのビュー
 *
 * @package ExternalLinkGateway
 * @since 1.0.0
 */

// 直接アクセスを防止
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

$general_settings = get_option( 'elg_general_settings', array() );
$exclusion_settings = get_option( 'elg_exclusion_settings', array() );
$appearance_settings = get_option( 'elg_appearance_settings', array() );
$security_settings = get_option( 'elg_security_settings', array() );
$analytics_settings = get_option( 'elg_analytics_settings', array() );
$advanced_settings = get_option( 'elg_advanced_settings', array() );

$active_tab = isset( $_GET['tab'] ) ? sanitize_text_field( wp_unslash( $_GET['tab'] ) ) : 'general';
?>

<div class="wrap elg-settings-wrap">
    <h1><?php echo esc_html( get_admin_page_title() ); ?></h1>

    <?php if ( isset( $_GET['updated'] ) && $_GET['updated'] === 'true' ) : ?>
        <div class="notice notice-success is-dismissible">
            <p><?php esc_html_e( 'Settings saved successfully.', 'external-link-gateway' ); ?></p>
        </div>
    <?php endif; ?>

    <nav class="nav-tab-wrapper">
        <a href="?page=elg-settings&tab=general" class="nav-tab <?php echo $active_tab === 'general' ? 'nav-tab-active' : ''; ?>">
            <?php esc_html_e( 'General', 'external-link-gateway' ); ?>
        </a>
        <a href="?page=elg-settings&tab=exclusion" class="nav-tab <?php echo $active_tab === 'exclusion' ? 'nav-tab-active' : ''; ?>">
            <?php esc_html_e( 'Exclusions', 'external-link-gateway' ); ?>
        </a>
        <a href="?page=elg-settings&tab=appearance" class="nav-tab <?php echo $active_tab === 'appearance' ? 'nav-tab-active' : ''; ?>">
            <?php esc_html_e( 'Appearance', 'external-link-gateway' ); ?>
        </a>
        <a href="?page=elg-settings&tab=security" class="nav-tab <?php echo $active_tab === 'security' ? 'nav-tab-active' : ''; ?>">
            <?php esc_html_e( 'Security', 'external-link-gateway' ); ?>
        </a>
        <a href="?page=elg-settings&tab=analytics" class="nav-tab <?php echo $active_tab === 'analytics' ? 'nav-tab-active' : ''; ?>">
            <?php esc_html_e( 'Analytics', 'external-link-gateway' ); ?>
        </a>
        <a href="?page=elg-settings&tab=advanced" class="nav-tab <?php echo $active_tab === 'advanced' ? 'nav-tab-active' : ''; ?>">
            <?php esc_html_e( 'Advanced', 'external-link-gateway' ); ?>
        </a>
    </nav>

    <form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
        <?php wp_nonce_field( 'elg_save_settings' ); ?>
        <input type="hidden" name="action" value="elg_save_settings">

        <div class="tab-content">
            <?php
            switch ( $active_tab ) {
                case 'general':
                    require ELG_PLUGIN_DIR . 'admin/views/settings/general.php';
                    break;
                case 'exclusion':
                    require ELG_PLUGIN_DIR . 'admin/views/settings/exclusion.php';
                    break;
                case 'appearance':
                    require ELG_PLUGIN_DIR . 'admin/views/settings/appearance.php';
                    break;
                case 'security':
                    require ELG_PLUGIN_DIR . 'admin/views/settings/security.php';
                    break;
                case 'analytics':
                    require ELG_PLUGIN_DIR . 'admin/views/settings/analytics.php';
                    break;
                case 'advanced':
                    require ELG_PLUGIN_DIR . 'admin/views/settings/advanced.php';
                    break;
            }
            ?>
        </div>

        <?php submit_button( __( 'Save Changes', 'external-link-gateway' ) ); ?>
    </form>
</div>
