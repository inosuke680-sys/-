<?php
/**
 * 統計ページのビュー
 *
 * @package ExternalLinkGateway
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}
?>

<div class="wrap elg-statistics-wrap">
    <h1><?php echo esc_html( get_admin_page_title() ); ?></h1>

    <div class="elg-stats-filters">
        <select id="elg-period-filter" onchange="window.location.href='?page=elg-statistics&period='+this.value">
            <option value="today" <?php selected( $period, 'today' ); ?>><?php esc_html_e( 'Today', 'external-link-gateway' ); ?></option>
            <option value="yesterday" <?php selected( $period, 'yesterday' ); ?>><?php esc_html_e( 'Yesterday', 'external-link-gateway' ); ?></option>
            <option value="last_7_days" <?php selected( $period, 'last_7_days' ); ?>><?php esc_html_e( 'Last 7 Days', 'external-link-gateway' ); ?></option>
            <option value="last_30_days" <?php selected( $period, 'last_30_days' ); ?>><?php esc_html_e( 'Last 30 Days', 'external-link-gateway' ); ?></option>
            <option value="last_90_days" <?php selected( $period, 'last_90_days' ); ?>><?php esc_html_e( 'Last 90 Days', 'external-link-gateway' ); ?></option>
            <option value="this_month" <?php selected( $period, 'this_month' ); ?>><?php esc_html_e( 'This Month', 'external-link-gateway' ); ?></option>
            <option value="all_time" <?php selected( $period, 'all_time' ); ?>><?php esc_html_e( 'All Time', 'external-link-gateway' ); ?></option>
        </select>
    </div>

    <div class="elg-stats-summary">
        <div class="elg-stat-box">
            <h3><?php esc_html_e( 'Total Clicks', 'external-link-gateway' ); ?></h3>
            <p class="elg-stat-number"><?php echo esc_html( number_format_i18n( $stats['total_clicks'] ) ); ?></p>
        </div>
    </div>

    <div class="elg-stats-section">
        <h2><?php esc_html_e( 'Top Links', 'external-link-gateway' ); ?></h2>
        <table class="wp-list-table widefat fixed striped">
            <thead>
                <tr>
                    <th><?php esc_html_e( 'URL', 'external-link-gateway' ); ?></th>
                    <th><?php esc_html_e( 'Domain', 'external-link-gateway' ); ?></th>
                    <th><?php esc_html_e( 'Clicks (Period)', 'external-link-gateway' ); ?></th>
                    <th><?php esc_html_e( 'Total Clicks', 'external-link-gateway' ); ?></th>
                </tr>
            </thead>
            <tbody>
                <?php if ( ! empty( $stats['top_links'] ) ) : ?>
                    <?php foreach ( $stats['top_links'] as $link ) : ?>
                        <tr>
                            <td><a href="<?php echo esc_url( $link->original_url ); ?>" target="_blank"><?php echo esc_html( wp_trim_words( $link->original_url, 10 ) ); ?></a></td>
                            <td><?php echo esc_html( $link->domain ); ?></td>
                            <td><?php echo esc_html( number_format_i18n( $link->period_clicks ) ); ?></td>
                            <td><?php echo esc_html( number_format_i18n( $link->click_count ) ); ?></td>
                        </tr>
                    <?php endforeach; ?>
                <?php else : ?>
                    <tr>
                        <td colspan="4"><?php esc_html_e( 'No data available', 'external-link-gateway' ); ?></td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>

    <div class="elg-stats-section">
        <h2><?php esc_html_e( 'Top Domains', 'external-link-gateway' ); ?></h2>
        <table class="wp-list-table widefat fixed striped">
            <thead>
                <tr>
                    <th><?php esc_html_e( 'Domain', 'external-link-gateway' ); ?></th>
                    <th><?php esc_html_e( 'Clicks', 'external-link-gateway' ); ?></th>
                </tr>
            </thead>
            <tbody>
                <?php if ( ! empty( $stats['top_domains'] ) ) : ?>
                    <?php foreach ( $stats['top_domains'] as $domain ) : ?>
                        <tr>
                            <td><?php echo esc_html( $domain->domain ); ?></td>
                            <td><?php echo esc_html( number_format_i18n( $domain->clicks ) ); ?></td>
                        </tr>
                    <?php endforeach; ?>
                <?php else : ?>
                    <tr>
                        <td colspan="2"><?php esc_html_e( 'No data available', 'external-link-gateway' ); ?></td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>
