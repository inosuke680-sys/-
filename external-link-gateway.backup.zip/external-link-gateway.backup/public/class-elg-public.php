<?php
/**
 * Publicクラス
 *
 * フロントエンド側の機能を管理します。
 *
 * @package ExternalLinkGateway
 * @since 1.0.0
 */

// 直接アクセスを防止
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * ELG_Public クラス
 */
class ELG_Public {

    /**
     * コンストラクタ
     */
    public function __construct() {
        add_action( 'wp_enqueue_scripts', array( $this, 'enqueue_scripts' ) );
        add_action( 'wp_head', array( $this, 'add_custom_head' ) );
    }

    /**
     * スクリプトとスタイルを読み込み
     */
    public function enqueue_scripts() {
        // CSS
        wp_enqueue_style(
            'elg-public',
            ELG_PLUGIN_URL . 'assets/css/public.css',
            array(),
            ELG_VERSION
        );

        // JavaScript
        wp_enqueue_script(
            'elg-public',
            ELG_PLUGIN_URL . 'assets/js/public.js',
            array( 'jquery' ),
            ELG_VERSION,
            true
        );

        // JavaScriptに変数を渡す
        wp_localize_script(
            'elg-public',
            'elgData',
            array(
                'ajaxUrl' => admin_url( 'admin-ajax.php' ),
                'nonce' => wp_create_nonce( 'elg-track-click' ),
                'homeUrl' => home_url(),
            )
        );
    }

    /**
     * カスタムヘッダーを追加
     */
    public function add_custom_head() {
        $appearance_settings = get_option( 'elg_appearance_settings', array() );

        // カスタムCSSがある場合は出力
        if ( ! empty( $appearance_settings['custom_css'] ) ) {
            echo '<style type="text/css">';
            echo wp_kses_post( $appearance_settings['custom_css'] );
            echo '</style>';
        }
    }
}
