<?php
/**
 * リダイレクトページテンプレート（日本語版）
 */
if ( ! defined( 'ABSPATH' ) ) exit;
?>
<!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
    <meta charset="<?php bloginfo( 'charset' ); ?>">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="robots" content="noindex, nofollow">
    <title><?php echo esc_html( $page_title ); ?> - <?php bloginfo( 'name' ); ?></title>

    <?php wp_head(); ?>

    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', 'Hiragino Sans', 'Hiragino Kaku Gothic ProN', 'Yu Gothic', Meiryo, sans-serif;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 20px;
        }

        .elg-redirect-container {
            background: white;
            border-radius: 16px;
            box-shadow: 0 20px 60px rgba(0, 0, 0, 0.3);
            max-width: 600px;
            width: 100%;
            padding: 48px;
            text-align: center;
            animation: slideUp 0.5s ease-out;
        }

        @keyframes slideUp {
            from {
                opacity: 0;
                transform: translateY(30px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }

        .elg-icon {
            width: 80px;
            height: 80px;
            margin: 0 auto 24px;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            animation: pulse 2s ease-in-out infinite;
        }

        @keyframes pulse {
            0%, 100% {
                transform: scale(1);
            }
            50% {
                transform: scale(1.05);
            }
        }

        .elg-icon svg {
            width: 40px;
            height: 40px;
            stroke: white;
            fill: none;
            stroke-width: 2;
            stroke-linecap: round;
            stroke-linejoin: round;
        }

        .elg-heading {
            font-size: 28px;
            font-weight: 700;
            color: #1a202c;
            margin-bottom: 16px;
        }

        .elg-message {
            font-size: 16px;
            color: #4a5568;
            margin-bottom: 24px;
            line-height: 1.6;
        }

        .elg-countdown {
            font-size: 48px;
            font-weight: 700;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            background-clip: text;
            margin: 32px 0;
        }

        .elg-countdown-text {
            font-size: 14px;
            color: #718096;
            margin-top: 8px;
        }

        .elg-url-box {
            background: #f7fafc;
            border: 1px solid #e2e8f0;
            border-radius: 8px;
            padding: 16px;
            margin: 24px 0;
            word-break: break-all;
        }

        .elg-url-label {
            font-size: 12px;
            color: #718096;
            text-transform: uppercase;
            letter-spacing: 0.5px;
            margin-bottom: 8px;
            font-weight: 600;
        }

        .elg-url {
            color: #667eea;
            font-size: 14px;
            text-decoration: none;
        }

        .elg-url:hover {
            text-decoration: underline;
        }

        .elg-warning {
            background: #fff5f5;
            border-left: 4px solid #f56565;
            padding: 16px;
            margin: 24px 0;
            text-align: left;
            border-radius: 4px;
        }

        .elg-warning-text {
            font-size: 14px;
            color: #742a2a;
            line-height: 1.6;
        }

        .elg-buttons {
            display: flex;
            gap: 16px;
            margin-top: 32px;
            justify-content: center;
            flex-wrap: wrap;
        }

        .elg-button {
            padding: 14px 32px;
            border: none;
            border-radius: 8px;
            font-size: 16px;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.3s ease;
            text-decoration: none;
            display: inline-block;
        }

        .elg-button-primary {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
        }

        .elg-button-primary:hover {
            transform: translateY(-2px);
            box-shadow: 0 10px 20px rgba(102, 126, 234, 0.4);
        }

        .elg-button-secondary {
            background: white;
            color: #4a5568;
            border: 2px solid #e2e8f0;
        }

        .elg-button-secondary:hover {
            background: #f7fafc;
            border-color: #cbd5e0;
        }

        .elg-progress-bar {
            width: 100%;
            height: 4px;
            background: #e2e8f0;
            border-radius: 2px;
            margin-top: 32px;
            overflow: hidden;
        }

        .elg-progress-fill {
            height: 100%;
            background: linear-gradient(90deg, #667eea 0%, #764ba2 100%);
            transition: width 0.1s linear;
            width: 100%;
        }

        .elg-footer {
            margin-top: 32px;
            padding-top: 24px;
            border-top: 1px solid #e2e8f0;
            font-size: 12px;
            color: #a0aec0;
        }

        .elg-footer a {
            color: #667eea;
            text-decoration: none;
        }

        .elg-footer a:hover {
            text-decoration: underline;
        }

        @media (max-width: 640px) {
            .elg-redirect-container {
                padding: 32px 24px;
            }

            .elg-heading {
                font-size: 24px;
            }

            .elg-countdown {
                font-size: 36px;
            }

            .elg-buttons {
                flex-direction: column;
            }

            .elg-button {
                width: 100%;
            }
        }

        <?php if ( ! empty( $custom_css ) ) : ?>
        /* Custom CSS */
        <?php echo wp_kses_post( $custom_css ); ?>
        <?php endif; ?>
    </style>
</head>
<body>
    <div class="elg-redirect-container">
        <div class="elg-icon">
            <svg viewBox="0 0 24 24">
                <path d="M18 13v6a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h6"></path>
                <polyline points="15 3 21 3 21 9"></polyline>
                <line x1="10" y1="14" x2="21" y2="3"></line>
            </svg>
        </div>

        <h1 class="elg-heading">外部サイトへ移動します</h1>
        <p class="elg-message">外部サイトへリダイレクトしています。しばらくお待ちください...</p>

        <?php if ( $show_countdown && $redirect_delay > 0 ) : ?>
        <div class="elg-countdown" id="elg-countdown"><?php echo absint( $redirect_delay ); ?></div>
        <div class="elg-countdown-text" id="elg-countdown-text">
            <span id="elg-seconds"><?php echo absint( $redirect_delay ); ?></span> 秒後に自動的にリダイレクトします
        </div>
        <?php endif; ?>

        <?php if ( $show_url ) : ?>
        <div class="elg-url-box">
            <div class="elg-url-label">移動先:</div>
            <a href="<?php echo esc_url( $destination_url ); ?>" class="elg-url" target="_blank" rel="noopener noreferrer">
                <?php echo esc_html( $destination_url ); ?>
            </a>
        </div>
        <?php endif; ?>

        <?php if ( $show_warning ) : ?>
        <div class="elg-warning">
            <p class="elg-warning-text">
                <?php echo esc_html( $warning_message ? $warning_message : '外部サイトへ移動します。移動先のサイトの内容については当サイトは責任を負いません。' ); ?>
            </p>
        </div>
        <?php endif; ?>

        <div class="elg-buttons">
            <a href="<?php echo esc_url( $destination_url ); ?>" class="elg-button elg-button-primary" id="elg-continue-btn">
                今すぐ移動する
            </a>
            <a href="javascript:history.back()" class="elg-button elg-button-secondary">
                戻る
            </a>
        </div>

        <div class="elg-progress-bar">
            <div class="elg-progress-fill" id="elg-progress"></div>
        </div>

        <div class="elg-footer">
            <?php bloginfo( 'name' ); ?> により保護されています
        </div>
    </div>

    <script>
        (function() {
            var redirectDelay = <?php echo absint( $redirect_delay ); ?>;
            var destinationUrl = <?php echo wp_json_encode( $destination_url ); ?>;
            var countdown = redirectDelay;
            var countdownElement = document.getElementById('elg-countdown');
            var secondsElement = document.getElementById('elg-seconds');
            var progressElement = document.getElementById('elg-progress');

            function updateCountdown() {
                if (countdownElement) {
                    countdownElement.textContent = countdown;
                }
                if (secondsElement) {
                    secondsElement.textContent = countdown;
                }
                if (progressElement) {
                    var progress = ((redirectDelay - countdown) / redirectDelay) * 100;
                    progressElement.style.width = progress + '%';
                }

                if (countdown <= 0) {
                    window.location.href = destinationUrl;
                } else {
                    countdown--;
                    setTimeout(updateCountdown, 1000);
                }
            }

            // カウントダウン開始
            if (redirectDelay > 0) {
                setTimeout(updateCountdown, 1000);
            } else {
                window.location.href = destinationUrl;
            }

            // Continue ボタンのクリック処理
            var continueBtn = document.getElementById('elg-continue-btn');
            if (continueBtn) {
                continueBtn.addEventListener('click', function(e) {
                    e.preventDefault();
                    window.location.href = destinationUrl;
                });
            }
        })();
    </script>

    <?php wp_footer(); ?>
</body>
</html>
