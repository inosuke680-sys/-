# External Link Gateway - Enterprise Edition

エンタープライズグレードの外部リンク管理プラグイン。大規模飲食店レビューサイト向けに最適化されたSEO対策ソリューション。

## 概要

External Link Gatewayは、外部リンクをクリックした際に中間ページを経由させることで、SEO上重要なリンクジュース（ページランク）の流出を防止します。KUSANAGI環境のWordPressに最適化されており、エンタープライズレベルの機能とパフォーマンスを提供します。

## 主要機能

### 🔗 リンク管理
- **自動リンク変換** - コンテンツ内の外部リンクを自動的に検出・変換
- **カスタマイズ可能な中間ページ** - デザインとメッセージを完全カスタマイズ
- **柔軟な除外設定** - ドメイン、URL、投稿タイプ別の除外ルール
- **ホワイトリスト機能** - 特定のドメインのみ変換対象に指定

### 🛡️ SEO最適化
- **rel="nofollow"** 自動付与でリンクジュースの流出を防止
- **rel="sponsored"** アフィリエイトリンクの適切なマーク
- **rel="ugc"** ユーザー生成コンテンツへの対応
- **noopener/noreferrer** セキュリティ対策も完備

### 📊 統計・アナリティクス
- **詳細なクリック追跡** - リンク別、ドメイン別の統計
- **デバイス検出** - デスクトップ/モバイル/タブレットの識別
- **ブラウザ検出** - 訪問者のブラウザ情報
- **時系列分析** - 日別、週別、月別のレポート
- **データエクスポート** - CSV形式でデータを出力

### 🔐 セキュリティ
- **URL検証** - 不正なURLのブロック
- **レート制限** - DDoS攻撃からの保護
- **IPブロックリスト** - 特定IPアドレスのブロック
- **XSS/CSRF対策** - 包括的なセキュリティ保護
- **SQLインジェクション対策** - プリペアードステートメント使用

### 📈 パフォーマンス
- **キャッシュ機能** - 高速なレスポンスタイム
- **データベース最適化** - インデックスによる高速検索
- **自動クリーンアップ** - 古いデータの自動削除
- **KUSANAGI最適化** - 高速WordPress環境に対応

### 🎨 カスタマイズ性
- **カスタムCSS** - 中間ページのデザインを自由にカスタマイズ
- **カスタムテンプレート** - 独自のHTMLテンプレート使用可能
- **フック・フィルター** - 開発者向けの豊富なAPI
- **REST API** - 外部システムとの統合

### 🌐 多言語対応
- **翻訳対応** - WordPress標準の多言語機能
- **日本語完全対応** - 日本市場向けに最適化

## インストール

### 必要要件
- WordPress 5.8以上
- PHP 7.4以上
- MySQL 5.7以上 または MariaDB 10.3以上
- KUSANAGI環境（推奨）

### インストール手順

1. プラグインをWordPressの `wp-content/plugins/` ディレクトリにアップロード
2. WordPress管理画面の「プラグイン」メニューからプラグインを有効化
3. 「Link Gateway」→「設定」から初期設定を行う

## 基本設定

### 一般設定
1. 管理画面で「Link Gateway」→「設定」→「一般」タブを開く
2. 「プラグインを有効化」にチェック
3. リダイレクトスラグを設定（例: `goto`）
4. リダイレクト遅延時間を設定（推奨: 3秒）
5. SEO設定で `rel="nofollow"` を有効化

### 除外設定
信頼できるパートナーサイトなどは除外リストに追加：

```
example.com
trusted-partner.com
```

### 外観設定
中間ページのメッセージをカスタマイズ：
- ページタイトル
- 見出し
- メッセージ
- カスタムCSS

## 使用方法

### 自動変換
プラグインを有効化すると、投稿・固定ページ・コメント内の外部リンクが自動的に変換されます。

### 手動での使用
特定のリンクのみ変換したい場合は、WordPress Shortcode APIを使用できます（カスタマイズが必要）。

### 統計の確認
「Link Gateway」→「ダッシュボード」で以下の情報を確認：
- 総クリック数
- トップリンク
- トップドメイン
- デバイス別統計
- ブラウザ別統計

## 開発者向け情報

### フィルターフック

```php
// リンク変換の除外判定をカスタマイズ
add_filter('elg_should_exclude_link', function($should_exclude, $url) {
    // カスタムロジック
    return $should_exclude;
}, 10, 2);

// リダイレクトURLをカスタマイズ
add_filter('elg_redirect_url', function($redirect_url, $original_url, $hash) {
    // カスタムロジック
    return $redirect_url;
}, 10, 3);
```

### アクションフック

```php
// リダイレクト前に処理を実行
add_action('elg_before_redirect', function($link_data) {
    // カスタム処理
});
```

### REST APIエンドポイント

#### 統計データ取得
```
GET /wp-json/elg/v1/statistics?period=last_30_days
```

#### リンク一覧取得
```
GET /wp-json/elg/v1/links?page=1&per_page=20
```

#### ログ取得
```
GET /wp-json/elg/v1/logs?level=error&limit=100
```

## トラブルシューティング

### リンクが変換されない
1. プラグインが有効化されているか確認
2. 「一般設定」で「プラグインを有効化」にチェックが入っているか確認
3. 除外設定を確認
4. ブラウザのキャッシュをクリア

### 中間ページが表示されない
1. パーマリンク設定を再保存（「設定」→「パーマリンク」→「変更を保存」）
2. .htaccessファイルのパーミッションを確認

### 統計が表示されない
1. 「アナリティクス設定」で追跡が有効になっているか確認
2. データベーステーブルが正しく作成されているか確認

## パフォーマンス最適化

### KUSANAGI環境での推奨設定
- Redis/Memcachedキャッシュの有効化
- OPcacheの有効化
- データベースクエリキャッシュの有効化

### 大規模サイト向け
- データ保持期間を適切に設定（推奨: 90日）
- 自動クリーンアップを有効化
- データベースインデックスの最適化（自動実行）

## セキュリティ

### 推奨設定
- URL検証を有効化
- レート制限を有効化
- IPアドレスの匿名化を有効化（GDPR対応）
- 不審なURLのブロックを有効化

## サポート・バグ報告

問題が発生した場合や機能リクエストがある場合は、以下の方法でご連絡ください：
- GitHub Issues: [リポジトリURL]
- メール: support@example.com

## ライセンス

GPL v2 or later

## クレジット

開発: Restaurant Review Team
バージョン: 1.0.0

---

## English Version

# External Link Gateway - Enterprise Edition

Enterprise-grade external link management plugin optimized for large-scale restaurant review sites with comprehensive SEO protection.

## Features

- Automatic external link conversion
- Customizable redirect pages
- Comprehensive analytics and statistics
- Advanced security features
- RESTful API
- Multi-site support
- GDPR compliant
- High-performance caching
- Device and browser detection
- Flexible exclusion rules

## Installation

1. Upload the plugin to `/wp-content/plugins/`
2. Activate through the WordPress plugins menu
3. Configure settings under "Link Gateway" → "Settings"

## Requirements

- WordPress 5.8+
- PHP 7.4+
- MySQL 5.7+ or MariaDB 10.3+

## Documentation

See README.md for detailed documentation in Japanese and English.

## License

GPL v2 or later
