/**
 * フロントエンド用JavaScript
 *
 * @package ExternalLinkGateway
 * @since 1.0.0
 */

(function($) {
    'use strict';

    $(document).ready(function() {
        ELGPublic.init();
    });

    /**
     * フロントエンド機能
     */
    var ELGPublic = {
        /**
         * 初期化
         */
        init: function() {
            this.trackExternalLinks();
        },

        /**
         * 外部リンクのクリックを追跡
         */
        trackExternalLinks: function() {
            $('a[data-elg-external]').on('click', function() {
                var linkId = $(this).data('elg-link-id');

                if (linkId && typeof elgData !== 'undefined') {
                    $.ajax({
                        url: elgData.ajaxUrl,
                        type: 'POST',
                        data: {
                            action: 'elg_track_click',
                            link_id: linkId,
                            nonce: elgData.nonce
                        }
                    });
                }
            });
        }
    };

})(jQuery);
