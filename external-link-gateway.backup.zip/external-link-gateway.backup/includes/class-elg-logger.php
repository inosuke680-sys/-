<?php
/**
 * ロガークラス
 *
 * エラー、警告、情報などのログを記録・管理します。
 *
 * @package ExternalLinkGateway
 * @since 1.0.0
 */

// 直接アクセスを防止
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * ELG_Logger クラス
 */
class ELG_Logger {

    /**
     * ログレベル
     *
     * @var array
     */
    private $log_levels = array(
        'debug' => 0,
        'info' => 1,
        'notice' => 2,
        'warning' => 3,
        'error' => 4,
        'critical' => 5,
        'alert' => 6,
        'emergency' => 7,
    );

    /**
     * 設定
     *
     * @var array
     */
    private $settings;

    /**
     * コンストラクタ
     */
    public function __construct() {
        $this->settings = get_option( 'elg_advanced_settings', array() );
    }

    /**
     * ログを記録
     *
     * @param string $level ログレベル
     * @param string $message メッセージ
     * @param array $context コンテキスト
     * @return bool
     */
    public function log( $level, $message, $context = array() ) {
        // デバッグモードが無効で、ログレベルが閾値以下の場合はスキップ
        if ( ! $this->should_log( $level ) ) {
            return false;
        }

        global $wpdb;

        $logs_table = $wpdb->prefix . 'elg_logs';

        $user_id = is_user_logged_in() ? get_current_user_id() : null;
        $ip_address = $this->get_client_ip();

        // コンテキストをJSON形式で保存
        $context_json = ! empty( $context ) ? wp_json_encode( $context ) : null;

        $data = array(
            'log_level' => $level,
            'message' => $message,
            'context' => $context_json,
            'user_id' => $user_id,
            'ip_address' => $ip_address,
            'created_at' => current_time( 'mysql' ),
        );

        $result = $wpdb->insert( $logs_table, $data );

        // クリティカルエラーの場合はメール通知（オプション）
        if ( in_array( $level, array( 'critical', 'alert', 'emergency' ), true ) ) {
            $this->send_alert_email( $level, $message, $context );
        }

        return $result !== false;
    }

    /**
     * ログを記録すべきかチェック
     *
     * @param string $level ログレベル
     * @return bool
     */
    private function should_log( $level ) {
        // デバッグモードの確認
        $debug_enabled = isset( $this->settings['enable_debug'] ) ? $this->settings['enable_debug'] : false;
        $min_log_level = isset( $this->settings['log_level'] ) ? $this->settings['log_level'] : 'error';

        // ログレベルの数値を取得
        $current_level = isset( $this->log_levels[ $level ] ) ? $this->log_levels[ $level ] : 0;
        $minimum_level = isset( $this->log_levels[ $min_log_level ] ) ? $this->log_levels[ $min_log_level ] : 0;

        // デバッグモードが無効で、現在のレベルが最小レベルより低い場合はログしない
        if ( ! $debug_enabled && $current_level < $minimum_level ) {
            return false;
        }

        return true;
    }

    /**
     * アラートメールを送信
     *
     * @param string $level ログレベル
     * @param string $message メッセージ
     * @param array $context コンテキスト
     */
    private function send_alert_email( $level, $message, $context = array() ) {
        // メール通知が有効かチェック（将来の拡張用）
        $email_alerts = apply_filters( 'elg_enable_email_alerts', false );

        if ( ! $email_alerts ) {
            return;
        }

        $admin_email = get_option( 'admin_email' );
        $site_name = get_bloginfo( 'name' );

        $subject = sprintf(
            /* translators: 1: log level, 2: site name */
            __( '[%1$s] Alert from %2$s - External Link Gateway', 'external-link-gateway' ),
            strtoupper( $level ),
            $site_name
        );

        $body = sprintf(
            __( "A %s level alert has been triggered on your site.\n\nMessage: %s\n\nContext: %s\n\nTime: %s", 'external-link-gateway' ),
            strtoupper( $level ),
            $message,
            wp_json_encode( $context, JSON_PRETTY_PRINT ),
            current_time( 'mysql' )
        );

        wp_mail( $admin_email, $subject, $body );
    }

    /**
     * デバッグログ
     *
     * @param string $message メッセージ
     * @param array $context コンテキスト
     * @return bool
     */
    public function debug( $message, $context = array() ) {
        return $this->log( 'debug', $message, $context );
    }

    /**
     * 情報ログ
     *
     * @param string $message メッセージ
     * @param array $context コンテキスト
     * @return bool
     */
    public function info( $message, $context = array() ) {
        return $this->log( 'info', $message, $context );
    }

    /**
     * 警告ログ
     *
     * @param string $message メッセージ
     * @param array $context コンテキスト
     * @return bool
     */
    public function warning( $message, $context = array() ) {
        return $this->log( 'warning', $message, $context );
    }

    /**
     * エラーログ
     *
     * @param string $message メッセージ
     * @param array $context コンテキスト
     * @return bool
     */
    public function error( $message, $context = array() ) {
        return $this->log( 'error', $message, $context );
    }

    /**
     * クリティカルログ
     *
     * @param string $message メッセージ
     * @param array $context コンテキスト
     * @return bool
     */
    public function critical( $message, $context = array() ) {
        return $this->log( 'critical', $message, $context );
    }

    /**
     * ログを取得
     *
     * @param array $args クエリ引数
     * @return array ログデータ
     */
    public function get_logs( $args = array() ) {
        global $wpdb;

        $defaults = array(
            'level' => null,
            'limit' => 100,
            'offset' => 0,
            'order' => 'DESC',
        );

        $args = wp_parse_args( $args, $defaults );

        $logs_table = $wpdb->prefix . 'elg_logs';

        $where = '1=1';

        if ( ! empty( $args['level'] ) ) {
            $where .= $wpdb->prepare( ' AND log_level = %s', $args['level'] );
        }

        $query = "SELECT * FROM {$logs_table} WHERE {$where} ORDER BY created_at {$args['order']} LIMIT %d OFFSET %d";

        $logs = $wpdb->get_results(
            $wpdb->prepare(
                $query,
                $args['limit'],
                $args['offset']
            )
        );

        // コンテキストをデコード
        foreach ( $logs as $log ) {
            if ( ! empty( $log->context ) ) {
                $log->context = json_decode( $log->context, true );
            }
        }

        return $logs;
    }

    /**
     * ログ数を取得
     *
     * @param string $level ログレベル
     * @return int ログ数
     */
    public function get_log_count( $level = null ) {
        global $wpdb;

        $logs_table = $wpdb->prefix . 'elg_logs';

        if ( $level ) {
            return $wpdb->get_var(
                $wpdb->prepare(
                    "SELECT COUNT(*) FROM {$logs_table} WHERE log_level = %s",
                    $level
                )
            );
        }

        return $wpdb->get_var( "SELECT COUNT(*) FROM {$logs_table}" );
    }

    /**
     * 古いログをクリーンアップ
     *
     * @param int $retention_days 保持日数
     * @return int 削除された行数
     */
    public function cleanup_old_logs( $retention_days ) {
        global $wpdb;

        $logs_table = $wpdb->prefix . 'elg_logs';

        $cutoff_date = gmdate( 'Y-m-d 00:00:00', strtotime( "-{$retention_days} days", current_time( 'timestamp' ) ) );

        $deleted = $wpdb->query(
            $wpdb->prepare(
                "DELETE FROM {$logs_table} WHERE created_at < %s",
                $cutoff_date
            )
        );

        return $deleted;
    }

    /**
     * すべてのログを削除
     *
     * @return bool
     */
    public function clear_all_logs() {
        global $wpdb;

        $logs_table = $wpdb->prefix . 'elg_logs';

        return $wpdb->query( "TRUNCATE TABLE {$logs_table}" ) !== false;
    }

    /**
     * クライアントIPアドレスを取得
     *
     * @return string IPアドレス
     */
    private function get_client_ip() {
        $ip_keys = array(
            'HTTP_CLIENT_IP',
            'HTTP_X_FORWARDED_FOR',
            'HTTP_X_FORWARDED',
            'HTTP_X_CLUSTER_CLIENT_IP',
            'HTTP_FORWARDED_FOR',
            'HTTP_FORWARDED',
            'REMOTE_ADDR',
        );

        foreach ( $ip_keys as $key ) {
            if ( isset( $_SERVER[ $key ] ) && filter_var( wp_unslash( $_SERVER[ $key ] ), FILTER_VALIDATE_IP ) ) {
                return sanitize_text_field( wp_unslash( $_SERVER[ $key ] ) );
            }
        }

        return '0.0.0.0';
    }
}
