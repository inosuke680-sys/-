<?php
/**
 * インストーラークラス
 *
 * プラグインのインストール、アップグレード、アンインストール処理を管理
 *
 * @package ExternalLinkGateway
 * @since 1.0.0
 */

// 直接アクセスを防止
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * ELG_Installer クラス
 */
class ELG_Installer {

    /**
     * データベースバージョン
     *
     * @var string
     */
    const DB_VERSION = '1.0.0';

    /**
     * プラグイン有効化時の処理
     */
    public static function activate() {
        global $wpdb;

        // マルチサイト対応
        if ( is_multisite() ) {
            $blog_ids = $wpdb->get_col( "SELECT blog_id FROM {$wpdb->blogs}" );
            foreach ( $blog_ids as $blog_id ) {
                switch_to_blog( $blog_id );
                self::create_tables();
                self::create_default_options();
                self::setup_capabilities();
                restore_current_blog();
            }
        } else {
            self::create_tables();
            self::create_default_options();
            self::setup_capabilities();
        }

        // リライトルールをフラッシュ
        flush_rewrite_rules();

        // インストール日時を記録
        update_option( 'elg_installed_date', current_time( 'mysql' ) );
        update_option( 'elg_db_version', self::DB_VERSION );
    }

    /**
     * プラグイン無効化時の処理
     */
    public static function deactivate() {
        // リライトルールをフラッシュ
        flush_rewrite_rules();

        // スケジュールされたイベントをクリア
        wp_clear_scheduled_hook( 'elg_daily_cleanup' );
        wp_clear_scheduled_hook( 'elg_generate_statistics' );
    }

    /**
     * データベーステーブルの作成
     */
    private static function create_tables() {
        global $wpdb;

        $charset_collate = $wpdb->get_charset_collate();

        // リンクテーブル
        $links_table = $wpdb->prefix . 'elg_links';

        // クリックテーブル
        $clicks_table = $wpdb->prefix . 'elg_clicks';

        // ログテーブル
        $logs_table = $wpdb->prefix . 'elg_logs';

        // SQL文を作成
        $sql = array();

        // リンクテーブル
        $sql[] = "CREATE TABLE IF NOT EXISTS {$links_table} (
            id bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
            original_url varchar(2048) NOT NULL,
            hash_key varchar(64) NOT NULL,
            redirect_url varchar(2048) NOT NULL,
            title varchar(255) DEFAULT NULL,
            post_id bigint(20) UNSIGNED DEFAULT NULL,
            post_type varchar(50) DEFAULT NULL,
            domain varchar(255) NOT NULL,
            is_active tinyint(1) NOT NULL DEFAULT 1,
            is_nofollow tinyint(1) NOT NULL DEFAULT 1,
            is_sponsored tinyint(1) NOT NULL DEFAULT 0,
            is_ugc tinyint(1) NOT NULL DEFAULT 0,
            click_count bigint(20) UNSIGNED NOT NULL DEFAULT 0,
            last_clicked datetime DEFAULT NULL,
            created_at datetime NOT NULL,
            updated_at datetime NOT NULL,
            PRIMARY KEY  (id),
            UNIQUE KEY hash_key (hash_key),
            KEY original_url (original_url(191)),
            KEY domain (domain),
            KEY post_id (post_id),
            KEY is_active (is_active),
            KEY created_at (created_at),
            KEY click_count (click_count)
        ) {$charset_collate};";

        // クリックテーブル
        $sql[] = "CREATE TABLE IF NOT EXISTS {$clicks_table} (
            id bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
            link_id bigint(20) UNSIGNED NOT NULL,
            user_id bigint(20) UNSIGNED DEFAULT NULL,
            ip_address varchar(45) NOT NULL,
            user_agent varchar(255) DEFAULT NULL,
            referrer varchar(2048) DEFAULT NULL,
            country_code varchar(2) DEFAULT NULL,
            device_type varchar(20) DEFAULT NULL,
            browser varchar(50) DEFAULT NULL,
            os varchar(50) DEFAULT NULL,
            clicked_at datetime NOT NULL,
            PRIMARY KEY  (id),
            KEY link_id (link_id),
            KEY user_id (user_id),
            KEY ip_address (ip_address),
            KEY clicked_at (clicked_at),
            KEY device_type (device_type),
            CONSTRAINT fk_elg_clicks_link_id FOREIGN KEY (link_id) REFERENCES {$links_table} (id) ON DELETE CASCADE
        ) {$charset_collate};";

        // ログテーブル
        $sql[] = "CREATE TABLE IF NOT EXISTS {$logs_table} (
            id bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
            log_level varchar(20) NOT NULL DEFAULT 'info',
            message text NOT NULL,
            context longtext DEFAULT NULL,
            user_id bigint(20) UNSIGNED DEFAULT NULL,
            ip_address varchar(45) DEFAULT NULL,
            created_at datetime NOT NULL,
            PRIMARY KEY  (id),
            KEY log_level (log_level),
            KEY user_id (user_id),
            KEY created_at (created_at)
        ) {$charset_collate};";

        // テーブルを作成
        require_once ABSPATH . 'wp-admin/includes/upgrade.php';
        foreach ( $sql as $query ) {
            dbDelta( $query );
        }

        // インデックスの最適化（既存の場合はスキップ）
        self::optimize_tables();
    }

    /**
     * テーブルの最適化
     */
    private static function optimize_tables() {
        global $wpdb;

        $tables = array(
            $wpdb->prefix . 'elg_links',
            $wpdb->prefix . 'elg_clicks',
            $wpdb->prefix . 'elg_logs',
        );

        foreach ( $tables as $table ) {
            $wpdb->query( "OPTIMIZE TABLE {$table}" );
        }
    }

    /**
     * デフォルトオプションの作成
     */
    private static function create_default_options() {
        $default_options = array(
            'elg_general_settings' => array(
                'enable_plugin' => true,
                'redirect_slug' => 'goto',
                'redirect_delay' => 3,
                'auto_convert_links' => true,
                'open_in_new_tab' => true,
                'add_nofollow' => true,
                'add_sponsored' => false,
                'add_ugc' => false,
            ),
            'elg_exclusion_settings' => array(
                'exclude_domains' => array(),
                'exclude_urls' => array(),
                'exclude_post_types' => array(),
                'exclude_user_roles' => array(),
                'whitelist_domains' => array(),
            ),
            'elg_appearance_settings' => array(
                'page_title' => __( 'Redirecting...', 'external-link-gateway' ),
                'page_heading' => __( 'You are being redirected', 'external-link-gateway' ),
                'page_message' => __( 'Please wait while we redirect you to the external site...', 'external-link-gateway' ),
                'countdown_text' => __( 'Redirecting in {seconds} seconds', 'external-link-gateway' ),
                'continue_button_text' => __( 'Continue', 'external-link-gateway' ),
                'cancel_button_text' => __( 'Cancel', 'external-link-gateway' ),
                'show_countdown' => true,
                'show_url' => true,
                'show_warning' => true,
                'warning_message' => __( 'You are leaving our site. We are not responsible for the content of external websites.', 'external-link-gateway' ),
                'custom_css' => '',
                'use_custom_template' => false,
                'custom_template_path' => '',
            ),
            'elg_security_settings' => array(
                'validate_urls' => true,
                'block_suspicious_urls' => true,
                'allowed_protocols' => array( 'http', 'https' ),
                'block_ip_addresses' => array(),
                'rate_limiting' => true,
                'rate_limit_count' => 100,
                'rate_limit_period' => 3600,
                'enable_captcha' => false,
                'captcha_threshold' => 10,
            ),
            'elg_analytics_settings' => array(
                'enable_tracking' => true,
                'track_anonymous' => true,
                'track_logged_in' => true,
                'enable_geolocation' => false,
                'enable_device_detection' => true,
                'retention_days' => 90,
                'anonymize_ip' => true,
            ),
            'elg_advanced_settings' => array(
                'enable_cache' => true,
                'cache_duration' => 3600,
                'enable_debug' => false,
                'log_level' => 'error',
                'cleanup_enabled' => true,
                'cleanup_interval' => 'daily',
                'export_format' => 'csv',
            ),
        );

        foreach ( $default_options as $option_name => $option_value ) {
            if ( ! get_option( $option_name ) ) {
                add_option( $option_name, $option_value );
            }
        }
    }

    /**
     * 権限の設定
     */
    private static function setup_capabilities() {
        $admin_role = get_role( 'administrator' );

        $capabilities = array(
            'manage_elg_settings',
            'view_elg_statistics',
            'manage_elg_links',
            'delete_elg_data',
        );

        if ( $admin_role ) {
            foreach ( $capabilities as $cap ) {
                $admin_role->add_cap( $cap );
            }
        }

        // エディターにも一部の権限を付与
        $editor_role = get_role( 'editor' );
        if ( $editor_role ) {
            $editor_role->add_cap( 'view_elg_statistics' );
        }
    }

    /**
     * プラグインのアンインストール
     * uninstall.php から呼ばれます
     */
    public static function uninstall() {
        global $wpdb;

        // オプションで完全削除が有効な場合のみ
        $keep_data = get_option( 'elg_keep_data_on_uninstall', false );

        if ( ! $keep_data ) {
            // マルチサイト対応
            if ( is_multisite() ) {
                $blog_ids = $wpdb->get_col( "SELECT blog_id FROM {$wpdb->blogs}" );
                foreach ( $blog_ids as $blog_id ) {
                    switch_to_blog( $blog_id );
                    self::delete_plugin_data();
                    restore_current_blog();
                }
            } else {
                self::delete_plugin_data();
            }
        }
    }

    /**
     * プラグインデータの削除
     */
    private static function delete_plugin_data() {
        global $wpdb;

        // テーブルの削除
        $tables = array(
            $wpdb->prefix . 'elg_links',
            $wpdb->prefix . 'elg_clicks',
            $wpdb->prefix . 'elg_logs',
        );

        foreach ( $tables as $table ) {
            $wpdb->query( "DROP TABLE IF EXISTS {$table}" );
        }

        // オプションの削除
        $options = array(
            'elg_general_settings',
            'elg_exclusion_settings',
            'elg_appearance_settings',
            'elg_security_settings',
            'elg_analytics_settings',
            'elg_advanced_settings',
            'elg_installed_date',
            'elg_db_version',
        );

        foreach ( $options as $option ) {
            delete_option( $option );
        }

        // 権限の削除
        $admin_role = get_role( 'administrator' );
        $editor_role = get_role( 'editor' );

        $capabilities = array(
            'manage_elg_settings',
            'view_elg_statistics',
            'manage_elg_links',
            'delete_elg_data',
        );

        if ( $admin_role ) {
            foreach ( $capabilities as $cap ) {
                $admin_role->remove_cap( $cap );
            }
        }

        if ( $editor_role ) {
            $editor_role->remove_cap( 'view_elg_statistics' );
        }

        // スケジュールされたイベントの削除
        wp_clear_scheduled_hook( 'elg_daily_cleanup' );
        wp_clear_scheduled_hook( 'elg_generate_statistics' );
    }
}
