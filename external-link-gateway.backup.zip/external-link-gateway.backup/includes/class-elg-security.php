<?php
/**
 * セキュリティクラス
 *
 * URL検証、レート制限、CSRF保護などのセキュリティ機能を提供します。
 *
 * @package ExternalLinkGateway
 * @since 1.0.0
 */

// 直接アクセスを防止
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * ELG_Security クラス
 */
class ELG_Security {

    /**
     * セキュリティ設定
     *
     * @var array
     */
    private $settings;

    /**
     * コンストラクタ
     */
    public function __construct() {
        $this->settings = get_option( 'elg_security_settings', array() );
    }

    /**
     * リクエストの検証
     *
     * @return bool
     */
    public function validate_request() {
        // レート制限チェック
        if ( ! empty( $this->settings['rate_limiting'] ) ) {
            if ( ! $this->check_rate_limit() ) {
                return false;
            }
        }

        // ブロックされたIPアドレスのチェック
        if ( ! empty( $this->settings['block_ip_addresses'] ) ) {
            if ( $this->is_ip_blocked() ) {
                return false;
            }
        }

        return true;
    }

    /**
     * URLの検証
     *
     * @param string $url URL
     * @return bool
     */
    public function validate_url( $url ) {
        // URL検証が無効の場合はtrueを返す
        if ( empty( $this->settings['validate_urls'] ) ) {
            return true;
        }

        // 基本的なURL検証
        if ( ! filter_var( $url, FILTER_VALIDATE_URL ) ) {
            return false;
        }

        // プロトコルチェック
        $parsed_url = parse_url( $url );

        if ( ! isset( $parsed_url['scheme'] ) ) {
            return false;
        }

        $allowed_protocols = isset( $this->settings['allowed_protocols'] ) ? $this->settings['allowed_protocols'] : array( 'http', 'https' );

        if ( ! in_array( strtolower( $parsed_url['scheme'] ), $allowed_protocols, true ) ) {
            return false;
        }

        // 不審なURLのブロック
        if ( ! empty( $this->settings['block_suspicious_urls'] ) ) {
            if ( $this->is_suspicious_url( $url ) ) {
                return false;
            }
        }

        return apply_filters( 'elg_validate_url', true, $url );
    }

    /**
     * レート制限のチェック
     *
     * @return bool
     */
    private function check_rate_limit() {
        $ip = $this->get_client_ip();

        $rate_limit_count = isset( $this->settings['rate_limit_count'] ) ? absint( $this->settings['rate_limit_count'] ) : 100;
        $rate_limit_period = isset( $this->settings['rate_limit_period'] ) ? absint( $this->settings['rate_limit_period'] ) : 3600;

        // トランジェントキーを生成
        $transient_key = 'elg_rate_limit_' . md5( $ip );

        // 現在のカウントを取得
        $count = get_transient( $transient_key );

        if ( false === $count ) {
            // 新しいカウントを開始
            set_transient( $transient_key, 1, $rate_limit_period );
            return true;
        }

        // カウントがリミットを超えているかチェック
        if ( $count >= $rate_limit_count ) {
            // ログに記録
            if ( class_exists( 'ELG_Logger' ) ) {
                $logger = new ELG_Logger();
                $logger->log( 'warning', 'Rate limit exceeded', array( 'ip' => $ip, 'count' => $count ) );
            }
            return false;
        }

        // カウントを増加
        set_transient( $transient_key, $count + 1, $rate_limit_period );

        return true;
    }

    /**
     * IPアドレスがブロックされているかチェック
     *
     * @return bool
     */
    private function is_ip_blocked() {
        $ip = $this->get_client_ip();

        if ( empty( $this->settings['block_ip_addresses'] ) ) {
            return false;
        }

        $blocked_ips = $this->settings['block_ip_addresses'];

        foreach ( $blocked_ips as $blocked_ip ) {
            // CIDR表記のサポート
            if ( strpos( $blocked_ip, '/' ) !== false ) {
                if ( $this->ip_in_range( $ip, $blocked_ip ) ) {
                    return true;
                }
            } elseif ( $ip === $blocked_ip ) {
                return true;
            }
        }

        return false;
    }

    /**
     * 不審なURLかチェック
     *
     * @param string $url URL
     * @return bool
     */
    private function is_suspicious_url( $url ) {
        // 不審なパターンのリスト
        $suspicious_patterns = array(
            '/\b(exec|system|shell_exec|passthru|eval)\b/i',
            '/\b(javascript|data):/i',
            '/\.\./i', // ディレクトリトラバーサル
            '/<script/i',
            '/\bon\w+\s*=/i', // イベントハンドラ
        );

        foreach ( $suspicious_patterns as $pattern ) {
            if ( preg_match( $pattern, $url ) ) {
                // ログに記録
                if ( class_exists( 'ELG_Logger' ) ) {
                    $logger = new ELG_Logger();
                    $logger->log( 'warning', 'Suspicious URL detected', array( 'url' => $url, 'pattern' => $pattern ) );
                }
                return true;
            }
        }

        // 既知の悪意のあるドメインリスト（拡張可能）
        $blacklisted_domains = apply_filters( 'elg_blacklisted_domains', array() );

        $parsed_url = parse_url( $url );
        $host = isset( $parsed_url['host'] ) ? strtolower( $parsed_url['host'] ) : '';

        if ( in_array( $host, $blacklisted_domains, true ) ) {
            return true;
        }

        return false;
    }

    /**
     * IPアドレスが範囲内にあるかチェック（CIDR表記対応）
     *
     * @param string $ip IPアドレス
     * @param string $range CIDR表記の範囲
     * @return bool
     */
    private function ip_in_range( $ip, $range ) {
        if ( strpos( $range, '/' ) === false ) {
            return $ip === $range;
        }

        list( $subnet, $mask ) = explode( '/', $range );

        $ip_long = ip2long( $ip );
        $subnet_long = ip2long( $subnet );
        $mask_long = -1 << ( 32 - (int) $mask );
        $subnet_long &= $mask_long;

        return ( $ip_long & $mask_long ) === $subnet_long;
    }

    /**
     * クライアントのIPアドレスを取得
     *
     * @return string IPアドレス
     */
    private function get_client_ip() {
        $ip_keys = array(
            'HTTP_CLIENT_IP',
            'HTTP_X_FORWARDED_FOR',
            'HTTP_X_FORWARDED',
            'HTTP_X_CLUSTER_CLIENT_IP',
            'HTTP_FORWARDED_FOR',
            'HTTP_FORWARDED',
            'REMOTE_ADDR',
        );

        foreach ( $ip_keys as $key ) {
            if ( isset( $_SERVER[ $key ] ) && filter_var( wp_unslash( $_SERVER[ $key ] ), FILTER_VALIDATE_IP ) ) {
                return sanitize_text_field( wp_unslash( $_SERVER[ $key ] ) );
            }
        }

        return '0.0.0.0';
    }

    /**
     * データのサニタイズ
     *
     * @param mixed $data データ
     * @param string $type タイプ
     * @return mixed サニタイズされたデータ
     */
    public function sanitize_data( $data, $type = 'text' ) {
        switch ( $type ) {
            case 'email':
                return sanitize_email( $data );

            case 'url':
                return esc_url_raw( $data );

            case 'int':
                return absint( $data );

            case 'textarea':
                return sanitize_textarea_field( $data );

            case 'html':
                return wp_kses_post( $data );

            case 'text':
            default:
                return sanitize_text_field( $data );
        }
    }

    /**
     * XSS対策のためのエスケープ
     *
     * @param string $string 文字列
     * @param string $context コンテキスト
     * @return string エスケープされた文字列
     */
    public function escape( $string, $context = 'html' ) {
        switch ( $context ) {
            case 'attr':
                return esc_attr( $string );

            case 'url':
                return esc_url( $string );

            case 'js':
                return esc_js( $string );

            case 'textarea':
                return esc_textarea( $string );

            case 'html':
            default:
                return esc_html( $string );
        }
    }

    /**
     * nonceの生成
     *
     * @param string $action アクション名
     * @return string nonce
     */
    public function create_nonce( $action ) {
        return wp_create_nonce( $action );
    }

    /**
     * nonceの検証
     *
     * @param string $nonce nonce
     * @param string $action アクション名
     * @return bool
     */
    public function verify_nonce( $nonce, $action ) {
        return wp_verify_nonce( $nonce, $action );
    }

    /**
     * SQLインジェクション対策のためのプリペアードステートメント補助
     *
     * @param string $query クエリ
     * @param array $args 引数
     * @return string プリペアードクエリ
     */
    public function prepare_query( $query, $args = array() ) {
        global $wpdb;
        return $wpdb->prepare( $query, $args );
    }
}
