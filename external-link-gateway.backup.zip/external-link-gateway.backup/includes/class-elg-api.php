<?php
/**
 * APIクラス
 *
 * REST API エンドポイントを提供します。
 *
 * @package ExternalLinkGateway
 * @since 1.0.0
 */

// 直接アクセスを防止
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * ELG_API クラス
 */
class ELG_API {

    /**
     * API名前空間
     *
     * @var string
     */
    private $namespace = 'elg/v1';

    /**
     * コンストラクタ
     */
    public function __construct() {
        // REST APIフックは ELG_Core で登録されます
    }

    /**
     * REST APIルートを登録
     */
    public function register_routes() {
        // 統計データの取得
        register_rest_route(
            $this->namespace,
            '/statistics',
            array(
                'methods' => 'GET',
                'callback' => array( $this, 'get_statistics' ),
                'permission_callback' => array( $this, 'check_statistics_permission' ),
                'args' => array(
                    'period' => array(
                        'default' => 'last_30_days',
                        'sanitize_callback' => 'sanitize_text_field',
                    ),
                ),
            )
        );

        // リンク一覧の取得
        register_rest_route(
            $this->namespace,
            '/links',
            array(
                'methods' => 'GET',
                'callback' => array( $this, 'get_links' ),
                'permission_callback' => array( $this, 'check_manage_permission' ),
                'args' => array(
                    'page' => array(
                        'default' => 1,
                        'sanitize_callback' => 'absint',
                    ),
                    'per_page' => array(
                        'default' => 20,
                        'sanitize_callback' => 'absint',
                    ),
                ),
            )
        );

        // 個別リンクの取得
        register_rest_route(
            $this->namespace,
            '/links/(?P<id>\d+)',
            array(
                'methods' => 'GET',
                'callback' => array( $this, 'get_link' ),
                'permission_callback' => array( $this, 'check_manage_permission' ),
            )
        );

        // リンクの更新
        register_rest_route(
            $this->namespace,
            '/links/(?P<id>\d+)',
            array(
                'methods' => 'PUT',
                'callback' => array( $this, 'update_link' ),
                'permission_callback' => array( $this, 'check_manage_permission' ),
            )
        );

        // リンクの削除
        register_rest_route(
            $this->namespace,
            '/links/(?P<id>\d+)',
            array(
                'methods' => 'DELETE',
                'callback' => array( $this, 'delete_link' ),
                'permission_callback' => array( $this, 'check_manage_permission' ),
            )
        );

        // ログの取得
        register_rest_route(
            $this->namespace,
            '/logs',
            array(
                'methods' => 'GET',
                'callback' => array( $this, 'get_logs' ),
                'permission_callback' => array( $this, 'check_manage_permission' ),
                'args' => array(
                    'level' => array(
                        'default' => null,
                        'sanitize_callback' => 'sanitize_text_field',
                    ),
                    'limit' => array(
                        'default' => 100,
                        'sanitize_callback' => 'absint',
                    ),
                ),
            )
        );

        // データのエクスポート
        register_rest_route(
            $this->namespace,
            '/export',
            array(
                'methods' => 'GET',
                'callback' => array( $this, 'export_data' ),
                'permission_callback' => array( $this, 'check_manage_permission' ),
                'args' => array(
                    'period' => array(
                        'default' => 'all_time',
                        'sanitize_callback' => 'sanitize_text_field',
                    ),
                    'format' => array(
                        'default' => 'csv',
                        'sanitize_callback' => 'sanitize_text_field',
                    ),
                ),
            )
        );
    }

    /**
     * 統計データを取得
     *
     * @param WP_REST_Request $request リクエスト
     * @return WP_REST_Response レスポンス
     */
    public function get_statistics( $request ) {
        $period = $request->get_param( 'period' );

        $analytics = new ELG_Analytics();
        $stats = $analytics->get_statistics( array( 'period' => $period ) );

        return new WP_REST_Response( $stats, 200 );
    }

    /**
     * リンク一覧を取得
     *
     * @param WP_REST_Request $request リクエスト
     * @return WP_REST_Response レスポンス
     */
    public function get_links( $request ) {
        global $wpdb;

        $page = $request->get_param( 'page' );
        $per_page = $request->get_param( 'per_page' );
        $offset = ( $page - 1 ) * $per_page;

        $table = $wpdb->prefix . 'elg_links';

        $total = $wpdb->get_var( "SELECT COUNT(*) FROM {$table}" );

        $links = $wpdb->get_results(
            $wpdb->prepare(
                "SELECT * FROM {$table} ORDER BY created_at DESC LIMIT %d OFFSET %d",
                $per_page,
                $offset
            )
        );

        return new WP_REST_Response(
            array(
                'links' => $links,
                'total' => absint( $total ),
                'page' => $page,
                'per_page' => $per_page,
                'total_pages' => ceil( $total / $per_page ),
            ),
            200
        );
    }

    /**
     * 個別リンクを取得
     *
     * @param WP_REST_Request $request リクエスト
     * @return WP_REST_Response レスポンス
     */
    public function get_link( $request ) {
        global $wpdb;

        $id = $request->get_param( 'id' );
        $table = $wpdb->prefix . 'elg_links';

        $link = $wpdb->get_row(
            $wpdb->prepare(
                "SELECT * FROM {$table} WHERE id = %d",
                $id
            )
        );

        if ( ! $link ) {
            return new WP_Error( 'not_found', __( 'Link not found', 'external-link-gateway' ), array( 'status' => 404 ) );
        }

        return new WP_REST_Response( $link, 200 );
    }

    /**
     * リンクを更新
     *
     * @param WP_REST_Request $request リクエスト
     * @return WP_REST_Response レスポンス
     */
    public function update_link( $request ) {
        global $wpdb;

        $id = $request->get_param( 'id' );
        $table = $wpdb->prefix . 'elg_links';

        $data = array();

        if ( $request->has_param( 'is_active' ) ) {
            $data['is_active'] = $request->get_param( 'is_active' ) ? 1 : 0;
        }

        if ( $request->has_param( 'is_nofollow' ) ) {
            $data['is_nofollow'] = $request->get_param( 'is_nofollow' ) ? 1 : 0;
        }

        if ( $request->has_param( 'is_sponsored' ) ) {
            $data['is_sponsored'] = $request->get_param( 'is_sponsored' ) ? 1 : 0;
        }

        if ( $request->has_param( 'is_ugc' ) ) {
            $data['is_ugc'] = $request->get_param( 'is_ugc' ) ? 1 : 0;
        }

        if ( empty( $data ) ) {
            return new WP_Error( 'no_data', __( 'No data to update', 'external-link-gateway' ), array( 'status' => 400 ) );
        }

        $data['updated_at'] = current_time( 'mysql' );

        $updated = $wpdb->update( $table, $data, array( 'id' => $id ) );

        if ( false === $updated ) {
            return new WP_Error( 'update_failed', __( 'Failed to update link', 'external-link-gateway' ), array( 'status' => 500 ) );
        }

        return new WP_REST_Response( array( 'success' => true ), 200 );
    }

    /**
     * リンクを削除
     *
     * @param WP_REST_Request $request リクエスト
     * @return WP_REST_Response レスポンス
     */
    public function delete_link( $request ) {
        global $wpdb;

        $id = $request->get_param( 'id' );
        $table = $wpdb->prefix . 'elg_links';

        $deleted = $wpdb->delete( $table, array( 'id' => $id ) );

        if ( ! $deleted ) {
            return new WP_Error( 'delete_failed', __( 'Failed to delete link', 'external-link-gateway' ), array( 'status' => 500 ) );
        }

        return new WP_REST_Response( array( 'success' => true ), 200 );
    }

    /**
     * ログを取得
     *
     * @param WP_REST_Request $request リクエスト
     * @return WP_REST_Response レスポンス
     */
    public function get_logs( $request ) {
        $logger = new ELG_Logger();

        $args = array(
            'level' => $request->get_param( 'level' ),
            'limit' => $request->get_param( 'limit' ),
        );

        $logs = $logger->get_logs( $args );

        return new WP_REST_Response( $logs, 200 );
    }

    /**
     * データをエクスポート
     *
     * @param WP_REST_Request $request リクエスト
     * @return WP_REST_Response レスポンス
     */
    public function export_data( $request ) {
        $analytics = new ELG_Analytics();

        $args = array(
            'period' => $request->get_param( 'period' ),
            'format' => $request->get_param( 'format' ),
        );

        $data = $analytics->generate_export_data( $args );

        return new WP_REST_Response( $data, 200 );
    }

    /**
     * 統計閲覧権限のチェック
     *
     * @return bool
     */
    public function check_statistics_permission() {
        return current_user_can( 'view_elg_statistics' );
    }

    /**
     * 管理権限のチェック
     *
     * @return bool
     */
    public function check_manage_permission() {
        return current_user_can( 'manage_elg_settings' );
    }
}
