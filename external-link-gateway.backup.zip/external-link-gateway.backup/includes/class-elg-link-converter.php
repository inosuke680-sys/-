<?php
/**
 * リンク変換エンジン
 *
 * コンテンツ内の外部リンクを検出し、中間ページ経由のリンクに変換します。
 *
 * @package ExternalLinkGateway
 * @since 1.0.0
 */

// 直接アクセスを防止
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * ELG_Link_Converter クラス
 */
class ELG_Link_Converter {

    /**
     * 現在のサイトのドメイン
     *
     * @var string
     */
    private $site_domain;

    /**
     * 除外設定
     *
     * @var array
     */
    private $exclusion_settings;

    /**
     * 一般設定
     *
     * @var array
     */
    private $general_settings;

    /**
     * コンストラクタ
     */
    public function __construct() {
        $this->site_domain = parse_url( home_url(), PHP_URL_HOST );
        $this->exclusion_settings = get_option( 'elg_exclusion_settings', array() );
        $this->general_settings = get_option( 'elg_general_settings', array() );
    }

    /**
     * コンテンツ内のリンクを変換
     *
     * @param string $content コンテンツ
     * @return string 変換後のコンテンツ
     */
    public function convert_links( $content ) {
        // プラグインが無効の場合はそのまま返す
        if ( empty( $this->general_settings['enable_plugin'] ) ) {
            return $content;
        }

        // DOMDocumentを使用してHTMLを解析
        if ( ! class_exists( 'DOMDocument' ) ) {
            return $content;
        }

        // HTMLエンティティを保持
        $content = mb_convert_encoding( $content, 'HTML-ENTITIES', 'UTF-8' );

        $dom = new DOMDocument();

        // エラー抑制
        libxml_use_internal_errors( true );

        // HTML5対応のため、XML宣言とbodyタグでラップ
        $dom->loadHTML( '<?xml encoding="UTF-8"><div>' . $content . '</div>', LIBXML_HTML_NOIMPLIED | LIBXML_HTML_NODEFDTD );

        libxml_clear_errors();

        // すべてのaタグを取得
        $links = $dom->getElementsByTagName( 'a' );

        // リンクを配列に変換（逆順でループするため）
        $links_array = array();
        foreach ( $links as $link ) {
            $links_array[] = $link;
        }

        // 各リンクを処理
        foreach ( $links_array as $link ) {
            $this->process_link( $link );
        }

        // HTMLを取得
        $result = $dom->saveHTML();

        // ラップしたdivタグを削除
        $result = preg_replace( '/^<div>(.*)<\/div>$/s', '$1', $result );

        // XML宣言を削除
        $result = preg_replace( '/^<\?xml[^>]+>\s*/i', '', $result );

        return $result;
    }

    /**
     * 個別のリンクを処理
     *
     * @param DOMElement $link リンク要素
     */
    private function process_link( $link ) {
        $href = $link->getAttribute( 'href' );

        // hrefが空の場合はスキップ
        if ( empty( $href ) ) {
            return;
        }

        // 外部リンクかチェック
        if ( ! $this->is_external_link( $href ) ) {
            return;
        }

        // 除外チェック
        if ( $this->should_exclude_link( $href ) ) {
            return;
        }

        // 既に変換済みかチェック
        if ( $this->is_already_converted( $href ) ) {
            return;
        }

        // リンクを変換
        $converted_url = $this->create_redirect_url( $href );

        if ( $converted_url ) {
            // hrefを更新
            $link->setAttribute( 'href', $converted_url );

            // rel属性を追加
            $this->add_rel_attributes( $link );

            // 新しいタブで開く設定
            if ( ! empty( $this->general_settings['open_in_new_tab'] ) ) {
                $link->setAttribute( 'target', '_blank' );
            }

            // data属性を追加（JavaScriptでの追跡用）
            $link->setAttribute( 'data-elg-external', '1' );
            $link->setAttribute( 'data-elg-original-url', esc_attr( $href ) );
        }
    }

    /**
     * 外部リンクかどうかをチェック
     *
     * @param string $url URL
     * @return bool
     */
    private function is_external_link( $url ) {
        // 相対URLは内部リンク
        if ( strpos( $url, '/' ) === 0 && strpos( $url, '//' ) !== 0 ) {
            return false;
        }

        // アンカーリンクは内部リンク
        if ( strpos( $url, '#' ) === 0 ) {
            return false;
        }

        // JavaScriptやmailtoなどは除外
        $excluded_protocols = array( 'javascript:', 'mailto:', 'tel:', 'sms:', 'data:' );
        foreach ( $excluded_protocols as $protocol ) {
            if ( strpos( $url, $protocol ) === 0 ) {
                return false;
            }
        }

        // URLをパース
        $parsed_url = parse_url( $url );

        // ホストが無い場合は内部リンク
        if ( ! isset( $parsed_url['host'] ) ) {
            return false;
        }

        // ホストが現在のサイトと同じ場合は内部リンク
        if ( $parsed_url['host'] === $this->site_domain ) {
            return false;
        }

        // wwwの有無を考慮
        $host_without_www = preg_replace( '/^www\./', '', $parsed_url['host'] );
        $site_without_www = preg_replace( '/^www\./', '', $this->site_domain );

        if ( $host_without_www === $site_without_www ) {
            return false;
        }

        return true;
    }

    /**
     * リンクを除外すべきかチェック
     *
     * @param string $url URL
     * @return bool
     */
    private function should_exclude_link( $url ) {
        // ホワイトリストドメインのチェック
        if ( ! empty( $this->exclusion_settings['whitelist_domains'] ) ) {
            foreach ( $this->exclusion_settings['whitelist_domains'] as $domain ) {
                if ( empty( $domain ) ) {
                    continue;
                }

                $domain = trim( $domain );
                if ( strpos( $url, $domain ) !== false ) {
                    return false; // ホワイトリストにある場合は変換する
                }
            }
        }

        // 除外ドメインのチェック
        if ( ! empty( $this->exclusion_settings['exclude_domains'] ) ) {
            foreach ( $this->exclusion_settings['exclude_domains'] as $domain ) {
                if ( empty( $domain ) ) {
                    continue;
                }

                $domain = trim( $domain );
                if ( strpos( $url, $domain ) !== false ) {
                    return true;
                }
            }
        }

        // 除外URLのチェック
        if ( ! empty( $this->exclusion_settings['exclude_urls'] ) ) {
            foreach ( $this->exclusion_settings['exclude_urls'] as $excluded_url ) {
                if ( empty( $excluded_url ) ) {
                    continue;
                }

                $excluded_url = trim( $excluded_url );

                // 正規表現のチェック
                if ( strpos( $excluded_url, '*' ) !== false ) {
                    $pattern = str_replace( array( '.', '*' ), array( '\.', '.*' ), $excluded_url );
                    if ( preg_match( '/' . $pattern . '/', $url ) ) {
                        return true;
                    }
                } elseif ( strpos( $url, $excluded_url ) !== false ) {
                    return true;
                }
            }
        }

        // 投稿タイプの除外チェック
        if ( ! empty( $this->exclusion_settings['exclude_post_types'] ) && is_singular() ) {
            $post_type = get_post_type();
            if ( in_array( $post_type, $this->exclusion_settings['exclude_post_types'], true ) ) {
                return true;
            }
        }

        // ユーザーロールの除外チェック
        if ( ! empty( $this->exclusion_settings['exclude_user_roles'] ) && is_user_logged_in() ) {
            $user = wp_get_current_user();
            $user_roles = $user->roles;

            foreach ( $user_roles as $role ) {
                if ( in_array( $role, $this->exclusion_settings['exclude_user_roles'], true ) ) {
                    return true;
                }
            }
        }

        // フィルターフックで拡張可能
        return apply_filters( 'elg_should_exclude_link', false, $url );
    }

    /**
     * 既に変換済みかチェック
     *
     * @param string $url URL
     * @return bool
     */
    private function is_already_converted( $url ) {
        $settings = get_option( 'elg_general_settings', array() );
        $slug = isset( $settings['redirect_slug'] ) ? $settings['redirect_slug'] : 'goto';

        return strpos( $url, home_url( $slug ) ) !== false;
    }

    /**
     * リダイレクトURLを作成
     *
     * @param string $original_url オリジナルURL
     * @return string|false リダイレクトURL
     */
    private function create_redirect_url( $original_url ) {
        global $wpdb;

        // URLをサニタイズ
        $original_url = esc_url_raw( $original_url );

        // ハッシュを生成
        $hash = $this->generate_hash( $original_url );

        // データベースに既に存在するかチェック
        $table = $wpdb->prefix . 'elg_links';
        $existing = $wpdb->get_row(
            $wpdb->prepare(
                "SELECT * FROM {$table} WHERE hash_key = %s",
                $hash
            )
        );

        if ( ! $existing ) {
            // 新しいリンクをデータベースに保存
            $parsed = parse_url( $original_url );
            $domain = isset( $parsed['host'] ) ? $parsed['host'] : '';

            $settings = get_option( 'elg_general_settings', array() );
            $slug = isset( $settings['redirect_slug'] ) ? $settings['redirect_slug'] : 'goto';

            $redirect_url = home_url( $slug . '/' . $hash );

            $data = array(
                'original_url' => $original_url,
                'hash_key' => $hash,
                'redirect_url' => $redirect_url,
                'domain' => $domain,
                'post_id' => get_the_ID(),
                'post_type' => get_post_type(),
                'is_active' => 1,
                'is_nofollow' => ! empty( $settings['add_nofollow'] ) ? 1 : 0,
                'is_sponsored' => ! empty( $settings['add_sponsored'] ) ? 1 : 0,
                'is_ugc' => ! empty( $settings['add_ugc'] ) ? 1 : 0,
                'created_at' => current_time( 'mysql' ),
                'updated_at' => current_time( 'mysql' ),
            );

            $inserted = $wpdb->insert( $table, $data );

            if ( ! $inserted ) {
                return false;
            }
        } else {
            // 既存のリダイレクトURLを使用
            $redirect_url = $existing->redirect_url;

            // 更新日時を更新
            $wpdb->update(
                $table,
                array( 'updated_at' => current_time( 'mysql' ) ),
                array( 'hash_key' => $hash )
            );
        }

        return apply_filters( 'elg_redirect_url', $redirect_url, $original_url, $hash );
    }

    /**
     * URLのハッシュを生成
     *
     * @param string $url URL
     * @return string ハッシュ
     */
    private function generate_hash( $url ) {
        // セキュリティのため、URLとソルトを組み合わせてハッシュ化
        $salt = defined( 'AUTH_KEY' ) ? AUTH_KEY : 'elg-salt';
        $hash = hash( 'sha256', $url . $salt );

        // 短縮（最初の12文字を使用）
        return substr( $hash, 0, 12 );
    }

    /**
     * rel属性を追加
     *
     * @param DOMElement $link リンク要素
     */
    private function add_rel_attributes( $link ) {
        $rel_values = array();

        // 既存のrel属性を取得
        $existing_rel = $link->getAttribute( 'rel' );
        if ( ! empty( $existing_rel ) ) {
            $rel_values = explode( ' ', $existing_rel );
        }

        // nofollow
        if ( ! empty( $this->general_settings['add_nofollow'] ) && ! in_array( 'nofollow', $rel_values, true ) ) {
            $rel_values[] = 'nofollow';
        }

        // sponsored
        if ( ! empty( $this->general_settings['add_sponsored'] ) && ! in_array( 'sponsored', $rel_values, true ) ) {
            $rel_values[] = 'sponsored';
        }

        // ugc
        if ( ! empty( $this->general_settings['add_ugc'] ) && ! in_array( 'ugc', $rel_values, true ) ) {
            $rel_values[] = 'ugc';
        }

        // noopener noreferrer（セキュリティのため）
        if ( ! in_array( 'noopener', $rel_values, true ) ) {
            $rel_values[] = 'noopener';
        }
        if ( ! in_array( 'noreferrer', $rel_values, true ) ) {
            $rel_values[] = 'noreferrer';
        }

        // rel属性を設定
        if ( ! empty( $rel_values ) ) {
            $link->setAttribute( 'rel', implode( ' ', array_unique( $rel_values ) ) );
        }
    }

    /**
     * リンク情報を取得
     *
     * @param string $hash ハッシュキー
     * @return object|null リンク情報
     */
    public function get_link_by_hash( $hash ) {
        global $wpdb;

        $table = $wpdb->prefix . 'elg_links';

        return $wpdb->get_row(
            $wpdb->prepare(
                "SELECT * FROM {$table} WHERE hash_key = %s AND is_active = 1",
                $hash
            )
        );
    }
}
