<?php
/**
 * コアクラス
 *
 * プラグインのメインコアクラス。すべてのコンポーネントを初期化・管理します。
 *
 * @package ExternalLinkGateway
 * @since 1.0.0
 */

// 直接アクセスを防止
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * ELG_Core クラス
 */
class ELG_Core {

    /**
     * シングルトンインスタンス
     *
     * @var ELG_Core
     */
    private static $instance = null;

    /**
     * リンク変換エンジン
     *
     * @var ELG_Link_Converter
     */
    public $link_converter;

    /**
     * リダイレクトハンドラー
     *
     * @var ELG_Redirect_Handler
     */
    public $redirect_handler;

    /**
     * セキュリティマネージャー
     *
     * @var ELG_Security
     */
    public $security;

    /**
     * アナリティクス
     *
     * @var ELG_Analytics
     */
    public $analytics;

    /**
     * ロガー
     *
     * @var ELG_Logger
     */
    public $logger;

    /**
     * 管理画面
     *
     * @var ELG_Admin
     */
    public $admin;

    /**
     * パブリック
     *
     * @var ELG_Public
     */
    public $public;

    /**
     * API
     *
     * @var ELG_API
     */
    public $api;

    /**
     * コンストラクタ（プライベート）
     */
    private function __construct() {
        $this->init();
    }

    /**
     * シングルトンインスタンスを取得
     *
     * @return ELG_Core
     */
    public static function get_instance() {
        if ( null === self::$instance ) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    /**
     * 初期化
     */
    private function init() {
        // 依存クラスの読み込み
        $this->load_dependencies();

        // コンポーネントの初期化
        $this->init_components();

        // フックの登録
        $this->register_hooks();

        // カスタムエンドポイントの登録
        $this->register_endpoints();

        // スケジュールされたイベントの登録
        $this->schedule_events();
    }

    /**
     * 依存クラスの読み込み
     */
    private function load_dependencies() {
        // コアクラス
        require_once ELG_PLUGIN_DIR . 'includes/class-elg-link-converter.php';
        require_once ELG_PLUGIN_DIR . 'includes/class-elg-redirect-handler.php';
        require_once ELG_PLUGIN_DIR . 'includes/class-elg-security.php';
        require_once ELG_PLUGIN_DIR . 'includes/class-elg-analytics.php';
        require_once ELG_PLUGIN_DIR . 'includes/class-elg-logger.php';
        require_once ELG_PLUGIN_DIR . 'includes/class-elg-api.php';

        // 管理画面
        if ( is_admin() ) {
            require_once ELG_PLUGIN_DIR . 'admin/class-elg-admin.php';
            require_once ELG_PLUGIN_DIR . 'admin/class-elg-settings.php';
            require_once ELG_PLUGIN_DIR . 'admin/class-elg-statistics.php';
            require_once ELG_PLUGIN_DIR . 'admin/class-elg-logs.php';
        }

        // パブリック
        if ( ! is_admin() ) {
            require_once ELG_PLUGIN_DIR . 'public/class-elg-public.php';
        }
    }

    /**
     * コンポーネントの初期化
     */
    private function init_components() {
        // セキュリティを最初に初期化
        $this->security = new ELG_Security();

        // ロガーを初期化
        $this->logger = new ELG_Logger();

        // リンク変換エンジンを初期化
        $this->link_converter = new ELG_Link_Converter();

        // リダイレクトハンドラーを初期化
        $this->redirect_handler = new ELG_Redirect_Handler();

        // アナリティクスを初期化
        $this->analytics = new ELG_Analytics();

        // APIを初期化
        $this->api = new ELG_API();

        // 管理画面を初期化
        if ( is_admin() ) {
            $this->admin = new ELG_Admin();
        }

        // パブリックを初期化
        if ( ! is_admin() ) {
            $this->public = new ELG_Public();
        }
    }

    /**
     * フックの登録
     */
    private function register_hooks() {
        // 一般的なフック
        add_action( 'init', array( $this, 'register_rewrite_rules' ) );
        add_filter( 'query_vars', array( $this, 'add_query_vars' ) );
        add_action( 'template_redirect', array( $this, 'handle_redirect_request' ) );

        // コンテンツフィルター（優先度を低めに設定して他のプラグインの後に実行）
        add_filter( 'the_content', array( $this, 'filter_content' ), 999 );
        add_filter( 'comment_text', array( $this, 'filter_content' ), 999 );
        add_filter( 'widget_text', array( $this, 'filter_content' ), 999 );

        // 管理バーにリンク
        add_action( 'admin_bar_menu', array( $this, 'add_admin_bar_link' ), 999 );

        // AJAX ハンドラー
        add_action( 'wp_ajax_elg_track_click', array( $this, 'ajax_track_click' ) );
        add_action( 'wp_ajax_nopriv_elg_track_click', array( $this, 'ajax_track_click' ) );

        // プラグインアップグレードチェック
        add_action( 'admin_init', array( $this, 'check_upgrade' ) );
    }

    /**
     * カスタムエンドポイントの登録
     */
    private function register_endpoints() {
        // REST API エンドポイント
        add_action( 'rest_api_init', array( $this->api, 'register_routes' ) );
    }

    /**
     * スケジュールされたイベントの登録
     */
    private function schedule_events() {
        if ( ! wp_next_scheduled( 'elg_daily_cleanup' ) ) {
            wp_schedule_event( time(), 'daily', 'elg_daily_cleanup' );
        }

        if ( ! wp_next_scheduled( 'elg_generate_statistics' ) ) {
            wp_schedule_event( time(), 'hourly', 'elg_generate_statistics' );
        }

        add_action( 'elg_daily_cleanup', array( $this, 'daily_cleanup' ) );
        add_action( 'elg_generate_statistics', array( $this, 'generate_statistics' ) );
    }

    /**
     * リライトルールの登録
     */
    public function register_rewrite_rules() {
        $settings = get_option( 'elg_general_settings', array() );
        $slug = isset( $settings['redirect_slug'] ) ? $settings['redirect_slug'] : 'goto';

        add_rewrite_rule(
            '^' . $slug . '/([^/]+)/?$',
            'index.php?elg_redirect=1&elg_hash=$matches[1]',
            'top'
        );
    }

    /**
     * クエリ変数の追加
     *
     * @param array $vars クエリ変数
     * @return array
     */
    public function add_query_vars( $vars ) {
        $vars[] = 'elg_redirect';
        $vars[] = 'elg_hash';
        return $vars;
    }

    /**
     * リダイレクトリクエストの処理
     */
    public function handle_redirect_request() {
        if ( get_query_var( 'elg_redirect' ) ) {
            $hash = get_query_var( 'elg_hash' );
            if ( $hash ) {
                $this->redirect_handler->handle( $hash );
            }
        }
    }

    /**
     * コンテンツのフィルタリング
     *
     * @param string $content コンテンツ
     * @return string フィルタリングされたコンテンツ
     */
    public function filter_content( $content ) {
        $settings = get_option( 'elg_general_settings', array() );

        // プラグインが有効かチェック
        if ( empty( $settings['enable_plugin'] ) ) {
            return $content;
        }

        // 自動変換が有効かチェック
        if ( empty( $settings['auto_convert_links'] ) ) {
            return $content;
        }

        // コンテンツをフィルタリング
        return $this->link_converter->convert_links( $content );
    }

    /**
     * 管理バーにリンクを追加
     *
     * @param WP_Admin_Bar $wp_admin_bar 管理バー
     */
    public function add_admin_bar_link( $wp_admin_bar ) {
        if ( ! current_user_can( 'view_elg_statistics' ) ) {
            return;
        }

        $wp_admin_bar->add_node(
            array(
                'id'    => 'elg-stats',
                'title' => __( 'Link Gateway', 'external-link-gateway' ),
                'href'  => admin_url( 'admin.php?page=elg-statistics' ),
            )
        );
    }

    /**
     * AJAX クリック追跡
     */
    public function ajax_track_click() {
        check_ajax_referer( 'elg-track-click', 'nonce' );

        $link_id = isset( $_POST['link_id'] ) ? absint( $_POST['link_id'] ) : 0;

        if ( ! $link_id ) {
            wp_send_json_error( array( 'message' => __( 'Invalid link ID', 'external-link-gateway' ) ) );
        }

        // クリックを記録
        $result = $this->analytics->track_click( $link_id );

        if ( $result ) {
            wp_send_json_success( array( 'message' => __( 'Click tracked', 'external-link-gateway' ) ) );
        } else {
            wp_send_json_error( array( 'message' => __( 'Failed to track click', 'external-link-gateway' ) ) );
        }
    }

    /**
     * プラグインアップグレードのチェック
     */
    public function check_upgrade() {
        $current_version = get_option( 'elg_db_version' );

        if ( version_compare( $current_version, ELG_Installer::DB_VERSION, '<' ) ) {
            require_once ELG_PLUGIN_DIR . 'includes/class-elg-installer.php';
            ELG_Installer::activate();
        }
    }

    /**
     * 日次クリーンアップ
     */
    public function daily_cleanup() {
        $settings = get_option( 'elg_analytics_settings', array() );
        $retention_days = isset( $settings['retention_days'] ) ? absint( $settings['retention_days'] ) : 90;

        // 古いクリックデータを削除
        $this->analytics->cleanup_old_data( $retention_days );

        // 古いログを削除
        $this->logger->cleanup_old_logs( $retention_days );

        // テーブルの最適化
        $this->optimize_database();
    }

    /**
     * 統計の生成
     */
    public function generate_statistics() {
        // 統計データの生成・キャッシュ
        $this->analytics->generate_cached_statistics();
    }

    /**
     * データベースの最適化
     */
    private function optimize_database() {
        global $wpdb;

        $tables = array(
            $wpdb->prefix . 'elg_links',
            $wpdb->prefix . 'elg_clicks',
            $wpdb->prefix . 'elg_logs',
        );

        foreach ( $tables as $table ) {
            $wpdb->query( "OPTIMIZE TABLE {$table}" );
        }
    }

    /**
     * クローンの禁止
     */
    private function __clone() {}

    /**
     * アンシリアライズの禁止
     */
    public function __wakeup() {
        throw new Exception( 'Cannot unserialize singleton' );
    }
}
