<?php
/**
 * リダイレクトハンドラー
 *
 * 中間ページを表示し、外部サイトへのリダイレクトを処理します。
 *
 * @package ExternalLinkGateway
 * @since 1.0.0
 */

// 直接アクセスを防止
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * ELG_Redirect_Handler クラス
 */
class ELG_Redirect_Handler {

    /**
     * リンク情報
     *
     * @var object
     */
    private $link_data;

    /**
     * 設定
     *
     * @var array
     */
    private $settings;

    /**
     * コンストラクタ
     */
    public function __construct() {
        $this->settings = get_option( 'elg_general_settings', array() );
    }

    /**
     * リダイレクトリクエストを処理
     *
     * @param string $hash ハッシュキー
     */
    public function handle( $hash ) {
        // ハッシュをサニタイズ
        $hash = sanitize_text_field( $hash );

        // セキュリティチェック
        $security = new ELG_Security();
        if ( ! $security->validate_request() ) {
            $this->show_error_page( __( 'Security check failed.', 'external-link-gateway' ) );
            exit;
        }

        // リンク情報を取得
        $this->link_data = $this->get_link_data( $hash );

        if ( ! $this->link_data ) {
            $this->show_error_page( __( 'Invalid or expired link.', 'external-link-gateway' ) );
            exit;
        }

        // URLの検証
        if ( ! $security->validate_url( $this->link_data->original_url ) ) {
            $this->show_error_page( __( 'Invalid URL.', 'external-link-gateway' ) );
            exit;
        }

        // クリックを記録
        $this->track_click();

        // リダイレクト遅延が0の場合は即座にリダイレクト
        $delay = isset( $this->settings['redirect_delay'] ) ? absint( $this->settings['redirect_delay'] ) : 3;

        if ( $delay === 0 ) {
            $this->do_redirect();
        } else {
            // 中間ページを表示
            $this->show_redirect_page();
        }

        exit;
    }

    /**
     * リンクデータを取得
     *
     * @param string $hash ハッシュキー
     * @return object|null リンクデータ
     */
    private function get_link_data( $hash ) {
        global $wpdb;

        $table = $wpdb->prefix . 'elg_links';

        $link = $wpdb->get_row(
            $wpdb->prepare(
                "SELECT * FROM {$table} WHERE hash_key = %s AND is_active = 1",
                $hash
            )
        );

        return $link;
    }

    /**
     * クリックを記録
     */
    private function track_click() {
        global $wpdb;

        // アナリティクスが有効かチェック
        $analytics_settings = get_option( 'elg_analytics_settings', array() );

        if ( empty( $analytics_settings['enable_tracking'] ) ) {
            return;
        }

        // ログインユーザーの追跡設定
        if ( is_user_logged_in() && empty( $analytics_settings['track_logged_in'] ) ) {
            return;
        }

        // 匿名ユーザーの追跡設定
        if ( ! is_user_logged_in() && empty( $analytics_settings['track_anonymous'] ) ) {
            return;
        }

        // クリックデータを準備
        $clicks_table = $wpdb->prefix . 'elg_clicks';
        $links_table = $wpdb->prefix . 'elg_links';

        $user_id = is_user_logged_in() ? get_current_user_id() : null;
        $ip_address = $this->get_client_ip();

        // IPアドレスを匿名化
        if ( ! empty( $analytics_settings['anonymize_ip'] ) ) {
            $ip_address = $this->anonymize_ip( $ip_address );
        }

        $user_agent = isset( $_SERVER['HTTP_USER_AGENT'] ) ? sanitize_text_field( wp_unslash( $_SERVER['HTTP_USER_AGENT'] ) ) : '';
        $referrer = isset( $_SERVER['HTTP_REFERER'] ) ? esc_url_raw( wp_unslash( $_SERVER['HTTP_REFERER'] ) ) : '';

        // デバイス情報を取得
        $device_info = array();
        if ( ! empty( $analytics_settings['enable_device_detection'] ) ) {
            $device_info = $this->detect_device( $user_agent );
        }

        // クリックデータを挿入
        $data = array(
            'link_id' => $this->link_data->id,
            'user_id' => $user_id,
            'ip_address' => $ip_address,
            'user_agent' => substr( $user_agent, 0, 255 ),
            'referrer' => $referrer,
            'device_type' => isset( $device_info['device_type'] ) ? $device_info['device_type'] : null,
            'browser' => isset( $device_info['browser'] ) ? $device_info['browser'] : null,
            'os' => isset( $device_info['os'] ) ? $device_info['os'] : null,
            'clicked_at' => current_time( 'mysql' ),
        );

        $wpdb->insert( $clicks_table, $data );

        // リンクのクリック数を更新
        $wpdb->query(
            $wpdb->prepare(
                "UPDATE {$links_table} SET click_count = click_count + 1, last_clicked = %s WHERE id = %d",
                current_time( 'mysql' ),
                $this->link_data->id
            )
        );
    }

    /**
     * クライアントのIPアドレスを取得
     *
     * @return string IPアドレス
     */
    private function get_client_ip() {
        $ip_keys = array(
            'HTTP_CLIENT_IP',
            'HTTP_X_FORWARDED_FOR',
            'HTTP_X_FORWARDED',
            'HTTP_X_CLUSTER_CLIENT_IP',
            'HTTP_FORWARDED_FOR',
            'HTTP_FORWARDED',
            'REMOTE_ADDR',
        );

        foreach ( $ip_keys as $key ) {
            if ( isset( $_SERVER[ $key ] ) && filter_var( wp_unslash( $_SERVER[ $key ] ), FILTER_VALIDATE_IP ) ) {
                return sanitize_text_field( wp_unslash( $_SERVER[ $key ] ) );
            }
        }

        return '0.0.0.0';
    }

    /**
     * IPアドレスを匿名化
     *
     * @param string $ip IPアドレス
     * @return string 匿名化されたIPアドレス
     */
    private function anonymize_ip( $ip ) {
        // IPv4の場合
        if ( filter_var( $ip, FILTER_VALIDATE_IP, FILTER_FLAG_IPV4 ) ) {
            $parts = explode( '.', $ip );
            $parts[3] = '0';
            return implode( '.', $parts );
        }

        // IPv6の場合
        if ( filter_var( $ip, FILTER_VALIDATE_IP, FILTER_FLAG_IPV6 ) ) {
            $parts = explode( ':', $ip );
            $parts = array_slice( $parts, 0, 4 );
            return implode( ':', $parts ) . '::';
        }

        return $ip;
    }

    /**
     * デバイス情報を検出
     *
     * @param string $user_agent ユーザーエージェント
     * @return array デバイス情報
     */
    private function detect_device( $user_agent ) {
        $device_info = array(
            'device_type' => 'desktop',
            'browser' => 'unknown',
            'os' => 'unknown',
        );

        // デバイスタイプの検出
        if ( preg_match( '/mobile|android|iphone|ipad|ipod/i', $user_agent ) ) {
            if ( preg_match( '/ipad|tablet/i', $user_agent ) ) {
                $device_info['device_type'] = 'tablet';
            } else {
                $device_info['device_type'] = 'mobile';
            }
        }

        // ブラウザの検出
        if ( preg_match( '/Firefox/i', $user_agent ) ) {
            $device_info['browser'] = 'Firefox';
        } elseif ( preg_match( '/Chrome/i', $user_agent ) ) {
            $device_info['browser'] = 'Chrome';
        } elseif ( preg_match( '/Safari/i', $user_agent ) ) {
            $device_info['browser'] = 'Safari';
        } elseif ( preg_match( '/Edge/i', $user_agent ) ) {
            $device_info['browser'] = 'Edge';
        } elseif ( preg_match( '/MSIE|Trident/i', $user_agent ) ) {
            $device_info['browser'] = 'IE';
        }

        // OSの検出
        if ( preg_match( '/Windows/i', $user_agent ) ) {
            $device_info['os'] = 'Windows';
        } elseif ( preg_match( '/Macintosh|Mac OS X/i', $user_agent ) ) {
            $device_info['os'] = 'MacOS';
        } elseif ( preg_match( '/Linux/i', $user_agent ) ) {
            $device_info['os'] = 'Linux';
        } elseif ( preg_match( '/Android/i', $user_agent ) ) {
            $device_info['os'] = 'Android';
        } elseif ( preg_match( '/iOS|iPhone|iPad/i', $user_agent ) ) {
            $device_info['os'] = 'iOS';
        }

        return $device_info;
    }

    /**
     * リダイレクトを実行
     */
    private function do_redirect() {
        // フックを実行（カスタマイズ用）
        do_action( 'elg_before_redirect', $this->link_data );

        // リダイレクト
        wp_redirect( $this->link_data->original_url, 302 );
        exit;
    }

    /**
     * 中間ページを表示
     */
    private function show_redirect_page() {
        // 外観設定を取得
        $appearance_settings = get_option( 'elg_appearance_settings', array() );

        // カスタムテンプレートを使用する場合
        if ( ! empty( $appearance_settings['use_custom_template'] ) && ! empty( $appearance_settings['custom_template_path'] ) ) {
            $custom_template = locate_template( $appearance_settings['custom_template_path'] );
            if ( $custom_template ) {
                include $custom_template;
                return;
            }
        }

        // デフォルトテンプレートを使用
        $template_path = ELG_PLUGIN_DIR . 'public/templates/redirect-page.php';

        if ( file_exists( $template_path ) ) {
            // テンプレートに渡す変数
            $page_title = isset( $appearance_settings['page_title'] ) ? $appearance_settings['page_title'] : __( 'Redirecting...', 'external-link-gateway' );
            $page_heading = isset( $appearance_settings['page_heading'] ) ? $appearance_settings['page_heading'] : __( 'You are being redirected', 'external-link-gateway' );
            $page_message = isset( $appearance_settings['page_message'] ) ? $appearance_settings['page_message'] : __( 'Please wait while we redirect you to the external site...', 'external-link-gateway' );
            $countdown_text = isset( $appearance_settings['countdown_text'] ) ? $appearance_settings['countdown_text'] : __( 'Redirecting in {seconds} seconds', 'external-link-gateway' );
            $continue_button_text = isset( $appearance_settings['continue_button_text'] ) ? $appearance_settings['continue_button_text'] : __( 'Continue', 'external-link-gateway' );
            $cancel_button_text = isset( $appearance_settings['cancel_button_text'] ) ? $appearance_settings['cancel_button_text'] : __( 'Cancel', 'external-link-gateway' );
            $show_countdown = isset( $appearance_settings['show_countdown'] ) ? $appearance_settings['show_countdown'] : true;
            $show_url = isset( $appearance_settings['show_url'] ) ? $appearance_settings['show_url'] : true;
            $show_warning = isset( $appearance_settings['show_warning'] ) ? $appearance_settings['show_warning'] : true;
            $warning_message = isset( $appearance_settings['warning_message'] ) ? $appearance_settings['warning_message'] : __( 'You are leaving our site. We are not responsible for the content of external websites.', 'external-link-gateway' );
            $custom_css = isset( $appearance_settings['custom_css'] ) ? $appearance_settings['custom_css'] : '';
            $redirect_delay = isset( $this->settings['redirect_delay'] ) ? absint( $this->settings['redirect_delay'] ) : 3;
            $destination_url = $this->link_data->original_url;

            include $template_path;
        }
    }

    /**
     * エラーページを表示
     *
     * @param string $message エラーメッセージ
     */
    private function show_error_page( $message ) {
        wp_die(
            esc_html( $message ),
            esc_html__( 'Error', 'external-link-gateway' ),
            array(
                'response' => 404,
                'back_link' => true,
            )
        );
    }
}
