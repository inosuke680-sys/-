<?php
/**
 * アナリティクスクラス
 *
 * クリック統計やレポート生成などの分析機能を提供します。
 *
 * @package ExternalLinkGateway
 * @since 1.0.0
 */

// 直接アクセスを防止
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * ELG_Analytics クラス
 */
class ELG_Analytics {

    /**
     * アナリティクス設定
     *
     * @var array
     */
    private $settings;

    /**
     * コンストラクタ
     */
    public function __construct() {
        $this->settings = get_option( 'elg_analytics_settings', array() );
    }

    /**
     * クリックを追跡
     *
     * @param int $link_id リンクID
     * @return bool
     */
    public function track_click( $link_id ) {
        global $wpdb;

        // 追跡が無効の場合は何もしない
        if ( empty( $this->settings['enable_tracking'] ) ) {
            return false;
        }

        $clicks_table = $wpdb->prefix . 'elg_clicks';

        $user_id = is_user_logged_in() ? get_current_user_id() : null;
        $ip_address = $this->get_client_ip();

        // IPアドレスを匿名化
        if ( ! empty( $this->settings['anonymize_ip'] ) ) {
            $ip_address = $this->anonymize_ip( $ip_address );
        }

        $user_agent = isset( $_SERVER['HTTP_USER_AGENT'] ) ? sanitize_text_field( wp_unslash( $_SERVER['HTTP_USER_AGENT'] ) ) : '';

        $data = array(
            'link_id' => $link_id,
            'user_id' => $user_id,
            'ip_address' => $ip_address,
            'user_agent' => substr( $user_agent, 0, 255 ),
            'clicked_at' => current_time( 'mysql' ),
        );

        return $wpdb->insert( $clicks_table, $data );
    }

    /**
     * 統計データを取得
     *
     * @param array $args クエリ引数
     * @return array 統計データ
     */
    public function get_statistics( $args = array() ) {
        global $wpdb;

        $defaults = array(
            'period' => 'last_30_days',
            'group_by' => 'day',
            'link_id' => null,
            'limit' => 100,
        );

        $args = wp_parse_args( $args, $defaults );

        // 期間の計算
        $date_range = $this->calculate_date_range( $args['period'] );

        $links_table = $wpdb->prefix . 'elg_links';
        $clicks_table = $wpdb->prefix . 'elg_clicks';

        // 総クリック数
        $total_clicks = $wpdb->get_var(
            $wpdb->prepare(
                "SELECT COUNT(*) FROM {$clicks_table} WHERE clicked_at BETWEEN %s AND %s",
                $date_range['start'],
                $date_range['end']
            )
        );

        // トップリンク
        $top_links = $wpdb->get_results(
            $wpdb->prepare(
                "SELECT l.id, l.original_url, l.domain, l.click_count, COUNT(c.id) as period_clicks
                FROM {$links_table} l
                LEFT JOIN {$clicks_table} c ON l.id = c.link_id AND c.clicked_at BETWEEN %s AND %s
                GROUP BY l.id
                ORDER BY period_clicks DESC
                LIMIT %d",
                $date_range['start'],
                $date_range['end'],
                $args['limit']
            )
        );

        // トップドメイン
        $top_domains = $wpdb->get_results(
            $wpdb->prepare(
                "SELECT l.domain, COUNT(c.id) as clicks
                FROM {$links_table} l
                LEFT JOIN {$clicks_table} c ON l.id = c.link_id AND c.clicked_at BETWEEN %s AND %s
                WHERE l.domain != ''
                GROUP BY l.domain
                ORDER BY clicks DESC
                LIMIT 10",
                $date_range['start'],
                $date_range['end']
            )
        );

        // 時系列データ
        $timeline_data = $this->get_timeline_data( $date_range, $args['group_by'] );

        // デバイス別統計
        $device_stats = $wpdb->get_results(
            $wpdb->prepare(
                "SELECT device_type, COUNT(*) as count
                FROM {$clicks_table}
                WHERE clicked_at BETWEEN %s AND %s AND device_type IS NOT NULL
                GROUP BY device_type",
                $date_range['start'],
                $date_range['end']
            )
        );

        // ブラウザ別統計
        $browser_stats = $wpdb->get_results(
            $wpdb->prepare(
                "SELECT browser, COUNT(*) as count
                FROM {$clicks_table}
                WHERE clicked_at BETWEEN %s AND %s AND browser IS NOT NULL
                GROUP BY browser
                ORDER BY count DESC
                LIMIT 10",
                $date_range['start'],
                $date_range['end']
            )
        );

        return array(
            'total_clicks' => absint( $total_clicks ),
            'top_links' => $top_links,
            'top_domains' => $top_domains,
            'timeline' => $timeline_data,
            'device_stats' => $device_stats,
            'browser_stats' => $browser_stats,
            'period' => $args['period'],
            'date_range' => $date_range,
        );
    }

    /**
     * 時系列データを取得
     *
     * @param array $date_range 日付範囲
     * @param string $group_by グループ化単位
     * @return array 時系列データ
     */
    private function get_timeline_data( $date_range, $group_by = 'day' ) {
        global $wpdb;

        $clicks_table = $wpdb->prefix . 'elg_clicks';

        // グループ化のフォーマット
        $date_format = '%Y-%m-%d';
        if ( $group_by === 'hour' ) {
            $date_format = '%Y-%m-%d %H:00:00';
        } elseif ( $group_by === 'month' ) {
            $date_format = '%Y-%m-01';
        }

        $results = $wpdb->get_results(
            $wpdb->prepare(
                "SELECT DATE_FORMAT(clicked_at, %s) as date, COUNT(*) as clicks
                FROM {$clicks_table}
                WHERE clicked_at BETWEEN %s AND %s
                GROUP BY DATE_FORMAT(clicked_at, %s)
                ORDER BY date ASC",
                $date_format,
                $date_range['start'],
                $date_range['end'],
                $date_format
            )
        );

        return $results;
    }

    /**
     * 日付範囲を計算
     *
     * @param string $period 期間
     * @return array 日付範囲
     */
    private function calculate_date_range( $period ) {
        $end = current_time( 'mysql' );
        $start = '';

        switch ( $period ) {
            case 'today':
                $start = gmdate( 'Y-m-d 00:00:00', current_time( 'timestamp' ) );
                break;

            case 'yesterday':
                $start = gmdate( 'Y-m-d 00:00:00', strtotime( '-1 day', current_time( 'timestamp' ) ) );
                $end = gmdate( 'Y-m-d 23:59:59', strtotime( '-1 day', current_time( 'timestamp' ) ) );
                break;

            case 'last_7_days':
                $start = gmdate( 'Y-m-d 00:00:00', strtotime( '-7 days', current_time( 'timestamp' ) ) );
                break;

            case 'last_30_days':
                $start = gmdate( 'Y-m-d 00:00:00', strtotime( '-30 days', current_time( 'timestamp' ) ) );
                break;

            case 'last_90_days':
                $start = gmdate( 'Y-m-d 00:00:00', strtotime( '-90 days', current_time( 'timestamp' ) ) );
                break;

            case 'this_month':
                $start = gmdate( 'Y-m-01 00:00:00', current_time( 'timestamp' ) );
                break;

            case 'last_month':
                $start = gmdate( 'Y-m-01 00:00:00', strtotime( 'first day of last month', current_time( 'timestamp' ) ) );
                $end = gmdate( 'Y-m-t 23:59:59', strtotime( 'last day of last month', current_time( 'timestamp' ) ) );
                break;

            case 'this_year':
                $start = gmdate( 'Y-01-01 00:00:00', current_time( 'timestamp' ) );
                break;

            case 'all_time':
            default:
                $start = '2000-01-01 00:00:00';
                break;
        }

        return array(
            'start' => $start,
            'end' => $end,
        );
    }

    /**
     * 古いデータをクリーンアップ
     *
     * @param int $retention_days 保持日数
     * @return int 削除された行数
     */
    public function cleanup_old_data( $retention_days ) {
        global $wpdb;

        $clicks_table = $wpdb->prefix . 'elg_clicks';

        $cutoff_date = gmdate( 'Y-m-d 00:00:00', strtotime( "-{$retention_days} days", current_time( 'timestamp' ) ) );

        $deleted = $wpdb->query(
            $wpdb->prepare(
                "DELETE FROM {$clicks_table} WHERE clicked_at < %s",
                $cutoff_date
            )
        );

        return $deleted;
    }

    /**
     * 統計をキャッシュ
     */
    public function generate_cached_statistics() {
        $periods = array( 'today', 'last_7_days', 'last_30_days', 'this_month' );

        foreach ( $periods as $period ) {
            $stats = $this->get_statistics( array( 'period' => $period ) );
            set_transient( 'elg_stats_' . $period, $stats, HOUR_IN_SECONDS );
        }
    }

    /**
     * キャッシュされた統計を取得
     *
     * @param string $period 期間
     * @return array|false 統計データ
     */
    public function get_cached_statistics( $period = 'last_30_days' ) {
        return get_transient( 'elg_stats_' . $period );
    }

    /**
     * エクスポート用データを生成
     *
     * @param array $args クエリ引数
     * @return array エクスポートデータ
     */
    public function generate_export_data( $args = array() ) {
        global $wpdb;

        $defaults = array(
            'period' => 'all_time',
            'format' => 'csv',
        );

        $args = wp_parse_args( $args, $defaults );

        $date_range = $this->calculate_date_range( $args['period'] );

        $links_table = $wpdb->prefix . 'elg_links';
        $clicks_table = $wpdb->prefix . 'elg_clicks';

        $data = $wpdb->get_results(
            $wpdb->prepare(
                "SELECT
                    l.original_url,
                    l.domain,
                    l.click_count,
                    c.clicked_at,
                    c.ip_address,
                    c.device_type,
                    c.browser,
                    c.os
                FROM {$links_table} l
                LEFT JOIN {$clicks_table} c ON l.id = c.link_id
                WHERE c.clicked_at BETWEEN %s AND %s
                ORDER BY c.clicked_at DESC",
                $date_range['start'],
                $date_range['end']
            ),
            ARRAY_A
        );

        return $data;
    }

    /**
     * クライアントIPアドレスを取得
     *
     * @return string IPアドレス
     */
    private function get_client_ip() {
        $ip_keys = array(
            'HTTP_CLIENT_IP',
            'HTTP_X_FORWARDED_FOR',
            'HTTP_X_FORWARDED',
            'HTTP_X_CLUSTER_CLIENT_IP',
            'HTTP_FORWARDED_FOR',
            'HTTP_FORWARDED',
            'REMOTE_ADDR',
        );

        foreach ( $ip_keys as $key ) {
            if ( isset( $_SERVER[ $key ] ) && filter_var( wp_unslash( $_SERVER[ $key ] ), FILTER_VALIDATE_IP ) ) {
                return sanitize_text_field( wp_unslash( $_SERVER[ $key ] ) );
            }
        }

        return '0.0.0.0';
    }

    /**
     * IPアドレスを匿名化
     *
     * @param string $ip IPアドレス
     * @return string 匿名化されたIPアドレス
     */
    private function anonymize_ip( $ip ) {
        if ( filter_var( $ip, FILTER_VALIDATE_IP, FILTER_FLAG_IPV4 ) ) {
            $parts = explode( '.', $ip );
            $parts[3] = '0';
            return implode( '.', $parts );
        }

        if ( filter_var( $ip, FILTER_VALIDATE_IP, FILTER_FLAG_IPV6 ) ) {
            $parts = explode( ':', $ip );
            $parts = array_slice( $parts, 0, 4 );
            return implode( ':', $parts ) . '::';
        }

        return $ip;
    }
}
