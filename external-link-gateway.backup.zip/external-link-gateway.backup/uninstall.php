<?php
/**
 * アンインストール処理
 *
 * プラグインがアンインストールされた時に実行されます
 *
 * @package ExternalLinkGateway
 * @since 1.0.0
 */

// WP_UNINSTALL_PLUGIN が定義されていない場合は終了
if ( ! defined( 'WP_UNINSTALL_PLUGIN' ) ) {
    exit;
}

// インストーラークラスを読み込み
require_once plugin_dir_path( __FILE__ ) . 'includes/class-elg-installer.php';

// アンインストール処理を実行
if ( class_exists( 'ELG_Installer' ) ) {
    ELG_Installer::uninstall();
}
