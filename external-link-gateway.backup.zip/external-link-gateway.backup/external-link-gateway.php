<?php
/**
 * Plugin Name: External Link Gateway - Enterprise Edition
 * Plugin URI: https://example.com/external-link-gateway
 * Description: エンタープライズグレードの外部リンク管理プラグイン。SEO対策として外部リンクを中間ページ経由にし、リンクジュースの流出を防止します。大規模飲食店レビューサイト向けに最適化。
 * Version: 1.0.0
 * Author: Restaurant Review Team
 * Author URI: https://example.com
 * License: GPL v2 or later
 * License URI: https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain: external-link-gateway
 * Domain Path: /languages
 * Requires at least: 5.8
 * Requires PHP: 7.4
 * Network: true
 *
 * @package ExternalLinkGateway
 */

// 直接アクセスを防止
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

// プラグイン定数の定義
define( 'ELG_VERSION', '1.0.0' );
define( 'ELG_PLUGIN_FILE', __FILE__ );
define( 'ELG_PLUGIN_DIR', plugin_dir_path( __FILE__ ) );
define( 'ELG_PLUGIN_URL', plugin_dir_url( __FILE__ ) );
define( 'ELG_PLUGIN_BASENAME', plugin_basename( __FILE__ ) );

// 最小要件チェック
if ( version_compare( PHP_VERSION, '7.4', '<' ) ) {
    add_action( 'admin_notices', 'elg_php_version_notice' );
    return;
}

if ( version_compare( get_bloginfo( 'version' ), '5.8', '<' ) ) {
    add_action( 'admin_notices', 'elg_wp_version_notice' );
    return;
}

/**
 * PHP バージョン不足の通知
 */
function elg_php_version_notice() {
    ?>
    <div class="notice notice-error">
        <p><?php esc_html_e( 'External Link Gateway requires PHP version 7.4 or higher. Please update PHP.', 'external-link-gateway' ); ?></p>
    </div>
    <?php
}

/**
 * WordPress バージョン不足の通知
 */
function elg_wp_version_notice() {
    ?>
    <div class="notice notice-error">
        <p><?php esc_html_e( 'External Link Gateway requires WordPress version 5.8 or higher. Please update WordPress.', 'external-link-gateway' ); ?></p>
    </div>
    <?php
}

// オートローダー
spl_autoload_register( 'elg_autoloader' );

/**
 * クラスオートローダー
 *
 * @param string $class_name クラス名
 */
function elg_autoloader( $class_name ) {
    // プレフィックスチェック
    if ( strpos( $class_name, 'ELG_' ) !== 0 ) {
        return;
    }

    // クラス名をファイル名に変換
    $class_name = strtolower( str_replace( '_', '-', $class_name ) );
    $file = ELG_PLUGIN_DIR . 'includes/class-' . $class_name . '.php';

    // admin ディレクトリもチェック
    if ( ! file_exists( $file ) ) {
        $file = ELG_PLUGIN_DIR . 'admin/class-' . $class_name . '.php';
    }

    // public ディレクトリもチェック
    if ( ! file_exists( $file ) ) {
        $file = ELG_PLUGIN_DIR . 'public/class-' . $class_name . '.php';
    }

    if ( file_exists( $file ) ) {
        require_once $file;
    }
}

/**
 * プラグインの初期化
 */
function elg_init() {
    // 多言語化の読み込み
    load_plugin_textdomain(
        'external-link-gateway',
        false,
        dirname( ELG_PLUGIN_BASENAME ) . '/languages/'
    );

    // コアクラスの初期化
    if ( class_exists( 'ELG_Core' ) ) {
        ELG_Core::get_instance();
    }
}
add_action( 'plugins_loaded', 'elg_init' );

/**
 * プラグイン有効化フック
 */
function elg_activate() {
    // インストーラークラスの読み込み
    require_once ELG_PLUGIN_DIR . 'includes/class-elg-installer.php';

    if ( class_exists( 'ELG_Installer' ) ) {
        ELG_Installer::activate();
    }
}
register_activation_hook( __FILE__, 'elg_activate' );

/**
 * プラグイン無効化フック
 */
function elg_deactivate() {
    // インストーラークラスの読み込み
    require_once ELG_PLUGIN_DIR . 'includes/class-elg-installer.php';

    if ( class_exists( 'ELG_Installer' ) ) {
        ELG_Installer::deactivate();
    }
}
register_deactivation_hook( __FILE__, 'elg_deactivate' );

/**
 * プラグインアンインストール用のフックを登録
 * 実際の処理は uninstall.php で行われます
 */
// uninstall.php で処理

/**
 * メインプラグインインスタンスを取得
 *
 * @return ELG_Core|null
 */
function ELG() {
    if ( class_exists( 'ELG_Core' ) ) {
        return ELG_Core::get_instance();
    }
    return null;
}

// 管理画面での設定リンクを追加
add_filter( 'plugin_action_links_' . ELG_PLUGIN_BASENAME, 'elg_plugin_action_links' );

/**
 * プラグインページに設定リンクを追加
 *
 * @param array $links リンク配列
 * @return array 修正されたリンク配列
 */
function elg_plugin_action_links( $links ) {
    $settings_link = sprintf(
        '<a href="%s">%s</a>',
        admin_url( 'admin.php?page=elg-settings' ),
        esc_html__( 'Settings', 'external-link-gateway' )
    );

    $stats_link = sprintf(
        '<a href="%s">%s</a>',
        admin_url( 'admin.php?page=elg-statistics' ),
        esc_html__( 'Statistics', 'external-link-gateway' )
    );

    array_unshift( $links, $settings_link, $stats_link );

    return $links;
}
